import {InputError} from './booking.js';
export async function readBody(request) {
  const origin=new URL(request.url).origin;
  if(request.headers.get('Origin') && request.headers.get('Origin')!==origin) throw new InputError('Origen no permitido.',403);
  if(!(request.headers.get('Content-Type')||'').startsWith('application/json')) throw new InputError('Se requiere JSON.',415);
  const reader=request.body?.getReader();
  if(!reader) throw new InputError('Faltan datos.');
  let length=0; const chunks=[];
  while(true){const {done,value}=await reader.read(); if(done) break; length+=value.length; if(length>4096){await reader.cancel(); throw new InputError('Demasiados datos.',413);} chunks.push(value);}
  const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  let body;try{body=JSON.parse(new TextDecoder().decode(bytes));}catch{throw new InputError('JSON inválido.');}
  if(!body || typeof body!=='object' || Array.isArray(body)) throw new InputError('Datos inválidos.');
  return body;
}
