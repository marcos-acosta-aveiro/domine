import { InputError, validateDate, validatePatient, slotsFor } from './booking.js';
import {manage} from './manage.js';
import {readBody} from './http.js';
import {clinic} from '../config/clinic.js';
import {waitlist} from './waitlist.js';
import {prepareRecovery,sendNotifications} from './recovery.js';

const json = (data, status=200) => Response.json(data, { status, headers: {
  'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff', 'Referrer-Policy':'no-referrer'
}});
const rows = async (env, sql, ...args) => (await env.DB.prepare(sql).bind(...args).all()).results;

export async function availability(env, doc, service, date, excludeCode='') {
  validateDate(date);
  if (typeof doc !== 'string' || typeof service !== 'string' || doc.length > 64 || service.length > 64) throw new InputError('Selección inválida.');
  const tenant = env.TENANT_ID;
  const selected = await env.DB.prepare(`SELECT s.* FROM services s JOIN professional_services ps ON s.tenant_id=ps.tenant_id AND s.id=ps.service_id WHERE s.tenant_id=? AND s.id=? AND ps.professional_id=?`).bind(tenant,service,doc).first();
  if (!selected) throw new InputError('El profesional no ofrece ese tratamiento.');
  const weekday = new Date(date+'T12:00:00Z').getUTCDay();
  const schedule = await rows(env,'SELECT start_min,end_min FROM schedules WHERE tenant_id=? AND professional_id=? AND weekday=?',tenant,doc,weekday);
  const busy = await rows(env,`SELECT start_min,end_min FROM appointments WHERE tenant_id=? AND professional_id=? AND date=? AND status!='cancelled' AND code!=? UNION ALL SELECT start_min,end_min FROM blocks WHERE tenant_id=? AND professional_id=? AND date=?`,tenant,doc,date,excludeCode,tenant,doc,date);
  return { slots: slotsFor(date,selected.duration,schedule,busy), service: selected };
}

function receipt(row) {
  return { code:row.code, date:row.date, hora:`${String(Math.floor(row.start_min/60)).padStart(2,'0')}:${String(row.start_min%60).padStart(2,'0')}`, total:row.price, status:row.status };
}

export default {
  async scheduled(event,env,ctx){
    ctx.waitUntil((async()=>{try{await prepareRecovery(env,availability);await sendNotifications(env,availability);}catch{console.error(JSON.stringify({event:'recovery_failure'}));}})());
  },
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/api/')) return env.ASSETS.fetch(request);
    const trace = crypto.randomUUID();
    try {
      if(request.method==='GET' && url.pathname==='/api/clinic') return json({...clinic,whatsappEnabled:env.WHATSAPP_ENABLED==='true'&&Boolean(env.WHATSAPP_TOKEN&&env.WHATSAPP_PHONE_ID&&env.WHATSAPP_API_VERSION&&env.PUBLIC_URL&&env.WHATSAPP_AVAILABILITY_TEMPLATE&&env.WHATSAPP_REACTIVATION_TEMPLATE)});
      if(request.method==='POST' && ['/api/waitlist','/api/waitlist/leave'].includes(url.pathname))return json(await waitlist(request,env,url.pathname.endsWith('/leave')));
      if(request.method==='POST' && url.pathname.startsWith('/api/manage/')) return json(await manage(request,env,url.pathname.slice('/api/manage/'.length),availability));
      if (request.method === 'GET' && url.pathname === '/api/catalog') {
        const [specialties, professionals, services] = await Promise.all(['specialties','professionals','services'].map(table => rows(env,`SELECT data FROM ${table} WHERE tenant_id=? ORDER BY rowid`,env.TENANT_ID)));
        return json({ specialties:specialties.map(r=>JSON.parse(r.data)), professionals:professionals.map(r=>JSON.parse(r.data)), services:services.map(r=>JSON.parse(r.data)) });
      }
      if (request.method === 'GET' && url.pathname === '/api/availability') {
        const result = await availability(env,url.searchParams.get('doc'),url.searchParams.get('trat'),url.searchParams.get('fecha'));
        return json({ slots:result.slots, duration:result.service.duration, timezone:'America/Asuncion' });
      }
      if (request.method === 'POST' && url.pathname === '/api/appointments') {
        const body=await readBody(request);
        const patient=validatePatient(body);
        if (body.pago !== 'consultorio') throw new InputError('El pago online todavía no está habilitado.');
        if (typeof body.requestId !== 'string' || !/^[0-9a-f-]{36}$/.test(body.requestId)) throw new InputError('Identificador inválido.');
        const tenant=env.TENANT_ID;
        const previous=await env.DB.prepare('SELECT * FROM appointments WHERE tenant_id=? AND request_id=?').bind(tenant,body.requestId).first();
        if(previous) return json(receipt(previous));
        if (typeof body.hora !== 'string' || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(body.hora)) throw new InputError('Horario inválido.');
        const result=await availability(env,body.doc,body.trat,body.fecha);
        if(!result.slots.includes(body.hora)) throw new InputError('Ese horario ya no está disponible. Elegí otro.',409);
        const [h,m]=body.hora.split(':').map(Number), start=h*60+m;
        const code='SL-'+crypto.randomUUID().replaceAll('-','').toUpperCase();
        try {
          await env.DB.prepare('INSERT INTO appointments (code,tenant_id,request_id,professional_id,service_id,date,start_min,end_min,patient_json,price) VALUES (?,?,?,?,?,?,?,?,?,?)').bind(code,tenant,body.requestId,body.doc,body.trat,body.fecha,start,start+result.service.duration,JSON.stringify(patient),result.service.price).run();
        } catch(error) {
          const duplicate=await env.DB.prepare('SELECT * FROM appointments WHERE tenant_id=? AND request_id=?').bind(tenant,body.requestId).first();
          if(duplicate) return json(receipt(duplicate));
          if(String(error.message).includes('SLOT_CONFLICT')) throw new InputError('Ese horario acaba de reservarse. Elegí otro.',409);
          throw error;
        }
        return json({code,date:body.fecha,hora:body.hora,total:result.service.price,status:'confirmed'},201);
      }
      return json({error:'Ruta no encontrada.'},404);
    } catch(error) {
      const status=error instanceof InputError ? error.status : 500;
      // No patient data, URLs, request bodies or database exception messages in logs.
      console[status>=500?'error':'warn'](JSON.stringify({event:'api_failure',trace,status}));
      return json({error:status>=500?'No pudimos completar la operación. Intentá nuevamente.':error.message,trace},status);
    }
  }
};
