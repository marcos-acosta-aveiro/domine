
/* ═══════════════════════════════════════════════════════════════
   DATOS DE LA CLÍNICA
   Todo lo editable vive acá arriba: especialidades, cuadro médico,
   tratamientos y testimonios. Cambiando estos arrays cambia toda la web.
   ═══════════════════════════════════════════════════════════════ */

let enviando=false, requestId=null, requestFingerprint=null, confirmedTotal=null, availabilityVersion=0;
let CLINIC={name:'Clínica Dómine',changeNoticeHours:6,timezone:'America/Asuncion',demo:true};
let ESPECIALIDADES=[], DOCTORES=[], TRATAMIENTOS=[];
const TESTIMONIOS=[{"texto":"Llegué con una urgencia un martes a la mañana y me atendieron el mismo día. La Dra. Ferreira me explicó cada paso antes de tocarme un diente.","autor":"Lorena M.","detalle":"Paciente de odontología"},{"texto":"El mapeo de lunares me dio tranquilidad. Comparan las fotos con las del año pasado, así que uno ve que realmente hacen seguimiento.","autor":"Andrés G.","detalle":"Paciente de dermatología"},{"texto":"Reservé de noche desde el celular y al otro día me llegó el recordatorio por WhatsApp. Pude cambiar el horario respondiendo el mensaje.","autor":"Fabiana R.","detalle":"Paciente de clínica médica"}];
/* ═══════════════════════════════════════════════════════════════
   UTILIDADES
   ═══════════════════════════════════════════════════════════════ */

const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));
const gs  = (n) => n.toLocaleString('es-PY') + ' Gs';
const espNombre = (id) => ESPECIALIDADES.find(e => e.id === id)?.nombre ?? '';
const docPorId  = (id) => DOCTORES.find(d => d.id === id);

// Utilidades de presentación; disponibilidad y confirmación provienen de la API.
function escapeHTML(value){ return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function localISO(date){ return [date.getFullYear(),String(date.getMonth()+1).padStart(2,'0'),String(date.getDate()).padStart(2,'0')].join('-'); }
function clinicToday(){ return new Date(new Intl.DateTimeFormat('en-CA',{timeZone:'America/Asuncion',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())+'T00:00:00'); }
function resetDate(){ reserva.fecha=null; reserva.hora=null; $('#franjas').textContent='Elegí una fecha para ver los horarios.'; }

function toast(msg, tipo = 'ok'){
  const el = document.createElement('div');
  const estilo = tipo === 'error'
    ? 'bg-red-600 text-white'
    : 'bg-navy-900 text-white';
  el.className = `toast-in pointer-events-auto ${estilo} rounded-xl px-4 py-3 text-sm shadow-lift flex items-start gap-3`;
  el.textContent = msg;
  el.setAttribute('role', tipo === 'error' ? 'alert' : 'status');
  $('#toasts').appendChild(el);
  setTimeout(() => { el.style.transition = 'opacity .3s, transform .3s'; el.style.opacity = '0'; el.style.transform = 'translateY(-8px)'; setTimeout(() => el.remove(), 320); }, 3400);
}

/* ═══════════════════════════════════════════════════════════════
   NAVEGACIÓN ENTRE PESTAÑAS
   ═══════════════════════════════════════════════════════════════ */

function irA(tab){
  if(enviando || window.portalBusy) return;
  if(!['inicio','agendar','gestionar','espera'].includes(tab)) return;
  const moveFocus=document.activeElement?.closest('button,a')&&!document.activeElement.matches('.nav-tab');
  ['inicio','agendar','gestionar','espera'].forEach(id=>$('#panel-'+id)?.classList.toggle('hidden',tab!==id));
  $('#skip-link')?.setAttribute('href','#panel-'+tab);
  $$('.nav-tab').forEach(b => {
    const activo = b.id === 'tab-' + tab;
    b.setAttribute('aria-selected', activo);
    b.tabIndex = activo ? 0 : -1;
    b.className = 'nav-tab';
  });
  if(moveFocus){const heading=$('#panel-'+tab+' h1');if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true});}}
  window.scrollTo({ top: 0, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches||document.body.classList.contains('keyboard-mode')?'instant':'smooth' });
}
function scrollA(id){ $('#' + id).scrollIntoView({ behavior:motionBehavior(), block:'start' }); }

/* ═══════════════════════════════════════════════════════════════
   PESTAÑA INICIO — RENDER
   ═══════════════════════════════════════════════════════════════ */

// Los horarios del inicio se consultan en connection.js.

const specialtyIcons={odonto:'M8 4c-4 0-5 5-3 9l2 7h2l2-6h2l2 6h2l2-7c2-4 1-9-3-9l-4 1-4-1Z',derma:'M12 3C8 8 5 11 5 15a7 7 0 0 0 14 0c0-4-3-7-7-12Z',estetica:'m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z',clinica:'M9 3h6v6h6v6h-6v6H9v-6H3V9h6V3Z',nutri:'M12 20C2 18 3 7 5 6c3-2 5 0 7 0s4-2 7 0c2 1 3 12-7 14ZM12 6c0-3 2-4 5-4',kine:'M12 6a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm-6 4 6-2 6 2m-6-2v7m-5 6 5-6 5 6'};
function renderEspecialidades(){
  $('#grid-especialidades').innerHTML=ESPECIALIDADES.map(e=>{
    const count=DOCTORES.filter(d=>d.esp===e.id).length;
    return `<button class="specialty-item" onclick="atajoEspecialidad('${e.id}')"><span class="specialty-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="${specialtyIcons[e.id]||specialtyIcons.clinica}" stroke-linecap="round" stroke-linejoin="round"/></svg></span><span><h3>${escapeHTML(e.nombre)}</h3><p>${count} ${count===1?'profesional':'profesionales'} · Ver disponibilidad</p></span><svg class="arrow" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg></button>`;
  }).join('');
}

let filtroDoc = 'todos';
let doctorSearch='';
function buscarDoctores(value){doctorSearch=value.trim().toLocaleLowerCase('es');renderDoctores();}
function renderFiltros(){
 const opciones=[{id:'todos',nombre:'Todas'},...ESPECIALIDADES];
 $('#filtros-doctores').innerHTML=opciones.map(o=>`<button onclick="filtrarDoctores('${o.id}')" aria-pressed="${filtroDoc===o.id}">${escapeHTML(o.nombre)}</button>`).join('');
}
function filtrarDoctores(id){ filtroDoc = id; renderFiltros(); renderDoctores(); }

function estrellas(r){
  const llenas = Math.floor(r);
  return Array.from({ length:5 }, (_, i) => `
    <svg class="w-3.5 h-3.5 ${i < llenas ? 'text-amber-400' : 'text-slate-200'}" fill="currentColor" viewBox="0 0 20 20"><path d="M10 1.5l2.6 5.3 5.9.9-4.2 4.1 1 5.8L10 14.9l-5.3 2.7 1-5.8L1.5 7.7l5.9-.9L10 1.5Z"/></svg>`).join('');
}

function renderDoctores(){
 const lista=DOCTORES.filter(d=>(filtroDoc==='todos'||d.esp===filtroDoc)&&(!doctorSearch||d.nombre.toLocaleLowerCase('es').normalize('NFD').replace(/[\u0300-\u036f]/g,'').includes(doctorSearch.normalize('NFD').replace(/[\u0300-\u036f]/g,''))));
 $('#grid-doctores').innerHTML=lista.map(d=>`<article class="doctor-card"><div class="doctor-photo"><img src="${d.foto}" alt="${escapeHTML(d.nombre)}" loading="lazy" width="400" height="400"></div><div class="doctor-info"><h3>${escapeHTML(d.nombre)}</h3><p class="specialty">${escapeHTML(espNombre(d.esp))}</p><p class="description">${escapeHTML(d.bio)}</p><div class="doctor-actions"><button class="text-action" onclick="verFicha('${d.id}')">Conocer perfil</button><button class="btn btn-secondary" onclick="atajoDoctor('${d.id}')">Reservar turno</button></div></div></article>`).join('')||'<p class="empty-result" role="status">No encontramos profesionales con esa búsqueda. Probá otro nombre o especialidad.</p>';
}

function renderTestimonios(){
  $('#grid-testimonios').innerHTML = TESTIMONIOS.map(t => `
    <figure class="bg-white/5 border border-white/10 rounded-2xl p-6">
      <div class="flex gap-0.5 mb-4">${Array.from({length:5}, () => `<svg class="w-4 h-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20"><path d="M10 1.5l2.6 5.3 5.9.9-4.2 4.1 1 5.8L10 14.9l-5.3 2.7 1-5.8L1.5 7.7l5.9-.9L10 1.5Z"/></svg>`).join('')}</div>
      <blockquote class="text-slate-200 leading-relaxed mb-5">${t.texto}</blockquote>
      <figcaption>
        <p class="font-medium text-white text-sm">${t.autor}</p>
        <p class="text-xs text-slate-400">${t.detalle}</p>
      </figcaption>
    </figure>`).join('');
}

/* ─────────── Modal de ficha médica ─────────── */
let modalTrigger=null;
function verFicha(id){
  modalTrigger=document.activeElement;
  const d = docPorId(id);
  const trats = TRATAMIENTOS.filter(t => t.docs.includes(id));
  $('#modal-cuerpo').innerHTML = `
    <div class="relative">
      <img src="${d.foto}" alt="${d.nombre}" class="w-full h-56 object-cover">
      <button onclick="cerrarModal()" class="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/90 grid place-items-center hover:bg-white transition-colors" aria-label="Cerrar">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" d="M6 6l12 12M18 6L6 18"/></svg>
      </button>
    </div>
    <div class="p-6">
      <h3 id="modal-title" class="font-display text-xl font-800 mb-1">${d.nombre}</h3>
      <p class="text-sm text-aqua-700 mb-1">${espNombre(d.esp)}</p>
      <p class="text-xs text-slate-500 mb-4">${d.reg} · Atiende en ${d.idiomas.toLowerCase()}</p>
      <p class="text-sm text-slate-600 leading-relaxed mb-5">${d.bio}</p>

      <h4 class="font-display font-700 text-sm mb-2">Formación</h4>
      <ul class="space-y-1.5 mb-5">
        ${d.formacion.map(f => `<li class="text-sm text-slate-600 flex gap-2"><span class="text-aqua-600 mt-1.5 w-1 h-1 rounded-full bg-aqua-600 shrink-0"></span>${f}</li>`).join('')}
      </ul>

      <h4 class="font-display font-700 text-sm mb-2">Atiende</h4>
      <ul class="space-y-1.5 mb-6">
        ${trats.map(t => `<li class="text-sm text-slate-600 flex justify-between gap-3"><span>${t.nombre}</span><span class="text-slate-400 shrink-0">${t.min} min</span></li>`).join('')}
      </ul>

      <button onclick="cerrarModal(); atajoDoctor('${d.id}')" class="w-full py-3 rounded-xl bg-navy-900 text-white text-sm font-semibold hover:bg-navy-800 transition-colors">
        Agendar con ${d.nombre.split(' ').slice(0, 2).join(' ')}
      </button>
    </div>`;
  $('#modal-doctor').classList.remove('hidden');
  document.body.style.overflow = 'hidden';
  $$('body > header, body > main, body > footer').forEach(el => el.inert=true);
  $('#modal-doctor button').focus();
}
function cerrarModal(){
  if($('#modal-doctor').classList.contains('hidden')) return;
  $('#modal-doctor').classList.add('hidden'); document.body.style.overflow = '';
  $$('body > header, body > main, body > footer').forEach(el => el.inert=false);
  modalTrigger?.focus();
}
document.addEventListener('keydown', e => {
  if($('#modal-doctor').classList.contains('hidden')) return;
  if(e.key==='Escape') cerrarModal();
  if(e.key==='Tab') {
    const buttons=$$('#modal-doctor button'), first=buttons[0], last=buttons.at(-1);
    if(e.shiftKey && document.activeElement===first){ e.preventDefault(); last.focus(); }
    else if(!e.shiftKey && document.activeElement===last){ e.preventDefault(); first.focus(); }
  }
});

/* Atajos desde la home directo al wizard */
function atajoEspecialidad(espId){
  if(enviando) return;
  reiniciar();
  irA('agendar');
  elegirModo('especialidad');
  paso(1);
  setTimeout(() => seleccionarEspecialidad(espId), 60);
}
function atajoDoctor(docId){
  if(enviando) return;
  reiniciar();
  irA('agendar');
  elegirModo('profesional');
  paso(1);
  setTimeout(() => seleccionarDoctor(docId), 60);
}

/* ═══════════════════════════════════════════════════════════════
   WIZARD — ESTADO
   ═══════════════════════════════════════════════════════════════ */

const PASOS = ['Modalidad', 'Selección', 'Fecha y hora', 'Tus datos', 'Confirmación'];
let pasoActual = 1;

let reserva = {
  modo: null, esp: null, doc: null, trat: null,
  fecha: null, hora: null, pago: null,
  nombre:'', apellido:'', cod:'+595', tel:'', email:'', motivo:'', codigo:null
};

function renderStepper(){
  $('#stepper').innerHTML = PASOS.map((p, i) => {
    const n = i + 1;
    const estado = n < pasoActual ? 'hecho' : n === pasoActual ? 'activo' : 'pendiente';
    const clickable = n < pasoActual && pasoActual < 5;
    return `
      <button aria-label="Paso ${n}: ${p}" ${n===pasoActual ? 'aria-current="step"' : ''} ${clickable ? `onclick="saltarA(${n})"` : 'disabled'} class="flex items-center gap-2 min-w-0 ${clickable ? 'cursor-pointer' : 'cursor-default'}">
        <span class="w-7 h-7 rounded-full grid place-items-center text-xs font-semibold shrink-0 transition-colors ${
          estado === 'hecho'  ? 'bg-aqua-600 text-white' :
          estado === 'activo' ? 'bg-navy-900 text-white' : 'bg-slate-200 text-slate-500'
        }">${estado === 'hecho' ? '✓' : n}</span>
        <span class="text-xs font-medium truncate hidden sm:block ${estado === 'pendiente' ? 'text-slate-400' : 'text-navy-900'}">${p}</span>
      </button>`;
  }).join('');
  $('#barra-progreso').style.width = (pasoActual / PASOS.length * 100) + '%';
}

async function paso(delta){
  if(enviando) return;
  if (delta > 0 && !validarPaso()) return;
  if(delta>0 && pasoActual===4){ await confirmarReserva(); return; }
  const destino = Math.min(Math.max(pasoActual + delta, 1), PASOS.length);
  if (destino === pasoActual) return;
  const haciaAtras = delta < 0;
  pasoActual = destino;
  mostrarPaso(haciaAtras);
}

function saltarA(n){ if (!enviando && n < pasoActual) { pasoActual = n; mostrarPaso(true); } }

function mostrarPaso(haciaAtras = false){
  $$('.paso').forEach((s, i) => {
    const visible = i + 1 === pasoActual;
    s.classList.toggle('hidden', !visible);
    s.classList.remove('step-in', 'step-in-back');
    if (visible) s.classList.add(haciaAtras ? 'step-in-back' : 'step-in');
  });

  if (pasoActual === 2) renderPaso2();
  if (pasoActual === 3){ renderCalendario(); if (reserva.fecha) renderFranjas(); }
  if (pasoActual === 5) { generarComprobante(); $('#nav-wizard').classList.add('hidden'); $('#resumen').classList.add('hidden'); }
  else { $('#nav-wizard').classList.remove('hidden'); $('#resumen').classList.remove('hidden'); }

  $('#btn-atras').classList.toggle('invisible', pasoActual === 1);
  $('#btn-siguiente').textContent = pasoActual === 4 ? 'Confirmar turno' : 'Continuar';

  renderStepper();
  renderResumen();
  actualizarBotonSiguiente();
  $('#wizard').scrollIntoView({ behavior:motionBehavior(), block:'start' });
  const heading=$('#paso-'+pasoActual+' h2');
  heading.setAttribute('tabindex','-1'); heading.focus({preventScroll:true});
}

function actualizarBotonSiguiente(){
  const btn = $('#btn-siguiente');
  const ok = {
    1: !!reserva.modo,
    2: !!reserva.trat && !!reserva.doc,
    3: !!reserva.fecha && !!reserva.hora,
    4: !!reserva.pago
  }[pasoActual];
  btn.disabled = pasoActual <= 4 ? !ok : false;
}

function validarPaso(){
  if (pasoActual === 1 && !reserva.modo){ toast('Elegí cómo querés buscar tu turno.', 'error'); return false; }
  if (pasoActual === 2 && (!reserva.trat || !reserva.doc)){ toast('Seleccioná un tratamiento y un profesional.', 'error'); return false; }
  if (pasoActual === 3 && (!reserva.fecha || !reserva.hora)){ toast('Elegí una fecha y un horario.', 'error'); return false; }
  if (pasoActual === 4) return validarFormulario();
  return true;
}

/* ─────────── PASO 1 ─────────── */
function elegirModo(modo){
  if(reserva.modo===modo) return;
  resetDate();
  reserva.modo = modo;
  reserva.esp = null; reserva.doc = null; reserva.trat = null;
  $$('.modo-btn').forEach(b => b.setAttribute('aria-pressed', b.dataset.modo === modo));
  actualizarBotonSiguiente();
  renderResumen();
}

/* ─────────── PASO 2 ─────────── */
function renderPaso2(){
  $('#p2-tratamientos').innerHTML='';
  const porEsp = reserva.modo === 'especialidad';
  $('#p2-titulo').textContent = porEsp ? 'Elegí la especialidad' : 'Elegí al profesional';
  $('#p2-sub').textContent = porEsp
    ? 'Después vas a poder elegir el profesional y el tratamiento.'
    : 'Después vas a ver los tratamientos que atiende y su disponibilidad.';

  if (porEsp){
    $('#p2-lista-a').innerHTML = `
      <div class="grid sm:grid-cols-3 gap-3">
        ${ESPECIALIDADES.map(e => `
          <button onclick="seleccionarEspecialidad('${e.id}')" aria-pressed="${reserva.esp === e.id}" data-esp="${e.id}"
                  class="pick esp-btn text-left p-4 rounded-xl border border-slate-200">
            <p class="font-display font-700 text-[15px] mb-1">${e.nombre}</p>
            <p class="text-xs text-slate-500">${DOCTORES.filter(d => d.esp === e.id).length} profesionales</p>
          </button>`).join('')}
      </div>`;
    $('#p2-lista-b').innerHTML = '';
    if (reserva.esp) seleccionarEspecialidad(reserva.esp, true);
  } else {
    $('#p2-lista-a').innerHTML = `
      <div class="grid sm:grid-cols-2 gap-3">
        ${DOCTORES.map(d => `
          <button onclick="seleccionarDoctor('${d.id}')" aria-pressed="${reserva.doc === d.id}" data-doc="${d.id}"
                  class="pick doc-btn text-left p-4 rounded-xl border border-slate-200 flex gap-3.5 items-center">
            <img src="${d.foto}" alt="" class="w-12 h-12 rounded-full object-cover shrink-0">
            <span class="min-w-0">
              <span class="block font-display font-700 text-[15px] truncate">${d.nombre}</span>
              <span class="block text-xs text-aqua-700">${espNombre(d.esp)}</span>
              <span class="block text-[11px] text-slate-500">${d.reg}</span>
            </span>
          </button>`).join('')}
      </div>`;
    $('#p2-lista-b').innerHTML = '';
    if (reserva.doc) seleccionarDoctor(reserva.doc, true);
  }
}

function seleccionarEspecialidad(espId, silencioso = false){
  reserva.esp = espId;
  if (!silencioso){ reserva.doc = null; reserva.trat = null; resetDate(); }
  $$('.esp-btn').forEach(b => b.setAttribute('aria-pressed', b.dataset.esp === espId));

  const docs = DOCTORES.filter(d => d.esp === espId);
  $('#p2-lista-b').innerHTML = `
    <div class="step-in">
      <h3 class="font-display font-700 text-[15px] mb-3">Profesionales de ${espNombre(espId).toLowerCase()}</h3>
      <div class="grid sm:grid-cols-2 gap-3 mb-7">
        ${docs.map(d => `
          <button onclick="seleccionarDoctor('${d.id}', false, true)" aria-pressed="${reserva.doc === d.id}" data-doc="${d.id}"
                  class="pick doc-btn text-left p-4 rounded-xl border border-slate-200 flex gap-3.5 items-center">
            <img src="${d.foto}" alt="" class="w-12 h-12 rounded-full object-cover shrink-0">
            <span class="min-w-0">
              <span class="block font-display font-700 text-[15px] truncate">${d.nombre}</span>
              <span class="block text-[11px] text-slate-500">${d.reg}</span>
            </span>
          </button>`).join('')}
      </div>
    </div>`;
  if (reserva.doc) renderTratamientos(reserva.doc);
  else $('#p2-tratamientos').innerHTML = '';
  actualizarBotonSiguiente();
  renderResumen();
}

function seleccionarDoctor(docId, silencioso = false, desdeEsp = false){
  const d = docPorId(docId);
  reserva.doc = docId;
  if (!desdeEsp) reserva.esp = d.esp;
  if (!silencioso){ reserva.trat = null; resetDate(); }
  $$('.doc-btn').forEach(b => b.setAttribute('aria-pressed', b.dataset.doc === docId));
  renderTratamientos(docId);
  actualizarBotonSiguiente();
  renderResumen();
}

function renderTratamientos(docId){
  const d = docPorId(docId);
  const trats = TRATAMIENTOS.filter(t => t.docs.includes(docId));
  $('#p2-tratamientos').innerHTML = `
    <div class="step-in">
      <h3 class="font-display font-700 text-[15px] mb-3">Tratamientos de ${d.nombre}</h3>
      <div class="space-y-2.5">
        ${trats.map(t => `
          <button onclick="seleccionarTratamiento('${t.id}')" aria-pressed="${reserva.trat === t.id}" data-trat="${t.id}"
                  class="pick trat-btn w-full text-left p-4 rounded-xl border border-slate-200">
            <div class="flex flex-wrap items-start justify-between gap-3 mb-1.5">
              <p class="font-display font-700 text-[15px]">${t.nombre}</p>
              <div class="text-right shrink-0">
                <p class="font-display font-700 text-[15px]">${gs(t.gs)}</p>
              </div>
            </div>
            <p class="text-sm text-slate-600 leading-relaxed mb-2">${t.desc}</p>
            <span class="inline-flex items-center gap-1.5 text-xs text-slate-500">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path stroke-linecap="round" d="M12 7v5l3 2"/></svg>
              ${t.min} minutos de consulta
            </span>
          </button>`).join('')}
      </div>
    </div>`;
}

function seleccionarTratamiento(tId){
  reserva.trat = tId;
  reserva.fecha = null; reserva.hora = null;
  $$('.trat-btn').forEach(b => b.setAttribute('aria-pressed', b.dataset.trat === tId));
  actualizarBotonSiguiente();
  renderResumen();
}

/* ─────────── PASO 3: calendario y franjas ─────────── */
let mesVista = clinicToday();
mesVista.setDate(1);

function cambiarMes(delta){
  const nuevo = new Date(mesVista);
  nuevo.setMonth(nuevo.getMonth() + delta);
  const hoy = clinicToday(); hoy.setDate(1);
  const limite=clinicToday(); limite.setDate(limite.getDate()+90);
  if (nuevo < hoy || nuevo > limite) return;
  mesVista = nuevo;
  renderCalendario();
}

function esHabil(fecha){
  const d = fecha.getDay();          // 0 domingo, 6 sábado
  return d !== 0;                     // se atiende de lunes a sábado
}

function renderCalendario(){
  $('#mes-label').textContent = mesVista.toLocaleDateString('es-PY', { month:'long', year:'numeric' });

  const hoy = clinicToday();
  const limite=clinicToday(); limite.setDate(limite.getDate()+90);
  const primerDia = new Date(mesVista.getFullYear(), mesVista.getMonth(), 1);
  const diasEnMes = new Date(mesVista.getFullYear(), mesVista.getMonth() + 1, 0).getDate();
  let offset = primerDia.getDay() - 1; if (offset < 0) offset = 6;  // semana arranca el lunes

  const prevDisabled = mesVista.getFullYear() === hoy.getFullYear() && mesVista.getMonth() === hoy.getMonth();
  $('#mes-prev').disabled = prevDisabled;
  $('#mes-prev').classList.toggle('opacity-30', prevDisabled);
  $('#mes-prev').classList.toggle('cursor-not-allowed', prevDisabled);

  let html = Array.from({ length: offset }, () => '<span></span>').join('');
  for (let n = 1; n <= diasEnMes; n++){
    const f = new Date(mesVista.getFullYear(), mesVista.getMonth(), n);
    const iso = localISO(f);
    const pasado = f < hoy;
    const habil = esHabil(f);
    const libre = !pasado && habil && f<=limite;
    const sel = reserva.fecha === iso;
    html += `
      <button onclick="elegirFecha('${iso}')" aria-label="${f.toLocaleDateString('es-PY',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}" aria-pressed="${sel}" ${libre ? '' : 'disabled'}
              class="day h-9 rounded-lg text-sm border border-transparent transition-colors ${
                sel ? 'is-selected' : libre ? 'hover:border-aqua-600 hover:bg-aqua-50 text-navy-900' : ''
              }">${n}</button>`;
  }
  $('#calendario').innerHTML = html;
}

function elegirFecha(iso){
  reserva.fecha = iso;
  reserva.hora = null;
  renderCalendario();
  renderFranjas();
  actualizarBotonSiguiente();
  renderResumen();
}

async function renderFranjas(){
  const t = TRATAMIENTOS.find(x => x.id === reserva.trat);
  if (!reserva.fecha || !t) return;
  const selection=[reserva.doc,reserva.trat,reserva.fecha].join('|');
  const version=++availabilityVersion;
  $('#franjas').innerHTML='<p role="status" class="text-sm text-slate-500">Consultando horarios disponibles…</p>';
  let slots;
  try { slots=(await api('/api/availability?'+new URLSearchParams({doc:reserva.doc,trat:reserva.trat,fecha:reserva.fecha}))).slots; }
  catch(error){
    if(version!==availabilityVersion || selection!==[reserva.doc,reserva.trat,reserva.fecha].join('|')) return;
    $('#franjas').innerHTML=`<p role="alert" class="text-sm text-red-600">${escapeHTML(error.message)}</p><button onclick="renderFranjas()" class="mt-3 underline text-sm">Reintentar</button>`;
    reserva.hora=null; actualizarBotonSiguiente(); renderResumen(); return;
  }
  if(version!==availabilityVersion || selection!==[reserva.doc,reserva.trat,reserva.fecha].join('|')) return;
  if(!slots.includes(reserva.hora)){ reserva.hora=null; actualizarBotonSiguiente(); renderResumen(); }
  const f = new Date(reserva.fecha + 'T00:00:00');
  const sabado = f.getDay() === 6;
  const manana=slots.filter(h=>h<'12:30').map(hora=>({hora,ocupado:false}));
  const tarde=slots.filter(h=>h>='12:30').map(hora=>({hora,ocupado:false}));
  const libres=slots.length;

  const bloque = (titulo, slots) => slots.length ? `
    <div class="mb-6">
      <div class="flex items-center justify-between mb-3">
        <h3 class="font-display font-700 text-sm">${titulo}</h3>
        <span class="text-xs text-slate-500">${slots.filter(s => !s.ocupado).length} disponibles</span>
      </div>
      <div class="grid grid-cols-3 sm:grid-cols-4 gap-2">
        ${slots.map(s => `
          <button onclick="elegirHora('${s.hora}')" ${s.ocupado ? 'disabled' : ''} aria-pressed="${reserva.hora === s.hora}"
                  class="slot py-2 rounded-lg border border-slate-200 text-sm transition-colors hover:border-aqua-600">${s.hora}</button>`).join('')}
      </div>
    </div>` : '';

  $('#franjas').innerHTML = `
    <div class="step-in">
      <div class="flex items-center gap-2 mb-5 text-sm">
        <span class="w-1.5 h-1.5 rounded-full bg-aqua-500"></span>
        <span class="font-medium">${libres} horarios disponibles</span>
        <span class="text-slate-500">el ${f.toLocaleDateString('es-PY', { weekday:'long', day:'numeric', month:'long' })}</span>
      </div>
      ${bloque('Turno mañana', manana)}
      ${bloque('Turno tarde', tarde)}
      ${!libres ? '<p class="text-sm text-slate-600">No quedan horarios para este tratamiento. Probá con otra fecha.</p>' : ''}
      ${sabado ? '<p class="text-xs text-slate-500">Los sábados se atiende solo por la mañana.</p>' : ''}
    </div>`;
}

function elegirHora(h){
  reserva.hora = h;
  $$('.slot').forEach(b => b.setAttribute('aria-pressed', b.textContent.trim() === h));
  actualizarBotonSiguiente();
  renderResumen();
}

/* ─────────── PASO 4: formulario y pago ─────────── */
function elegirPago(tipo){
  if(tipo !== 'consultorio') return;
  reserva.pago = tipo;
  $$('.pago-btn').forEach(b => b.setAttribute('aria-pressed', b.dataset.pago === tipo));
  actualizarBotonSiguiente();
  renderResumen();
}

function marcarError(input, msg){
  input.classList.add('invalid');
  input.setAttribute('aria-invalid','true');
  const p = input.closest('div').querySelector('.err') || input.parentElement.parentElement.querySelector('.err');
  if (p){ p.id=input.id+'-error'; input.setAttribute('aria-describedby',p.id); p.textContent = msg; p.classList.remove('hidden'); }
}
function limpiarError(input){
  input.classList.remove('invalid');
  input.removeAttribute('aria-invalid'); input.removeAttribute('aria-describedby');
  const p = input.closest('div').querySelector('.err') || input.parentElement.parentElement.querySelector('.err');
  if (p) p.classList.add('hidden');
}

function validarFormulario(){
  let ok = true;
  const nombre = $('#f-nombre'), apellido = $('#f-apellido'), tel = $('#f-tel'), email = $('#f-email');
  [nombre, apellido, tel, email].forEach(limpiarError);

  if (nombre.value.trim().length < 2){ marcarError(nombre, 'Escribí tu nombre.'); ok = false; }
  if (apellido.value.trim().length < 2){ marcarError(apellido, 'Escribí tu apellido.'); ok = false; }
  if (tel.value.replace(/\D/g, '').length < 8){ marcarError(tel, 'Ingresá un número de WhatsApp válido.'); ok = false; }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim())){ marcarError(email, 'Revisá el correo, parece incompleto.'); ok = false; }
  if (!reserva.pago){ toast('Elegí cómo querés pagar.', 'error'); ok = false; }

  if (!ok){ toast('Faltan datos para confirmar el turno.', 'error'); $('#paso-4 .invalid')?.focus(); return false; }

  reserva.nombre = nombre.value.trim();
  reserva.apellido = apellido.value.trim();
  reserva.cod = $('#f-cod').value;
  reserva.tel = tel.value.trim();
  reserva.email = email.value.trim();
  reserva.motivo = $('#f-motivo').value.trim();
  return true;
}

/* ─────────── RESUMEN LATERAL ─────────── */
function precioFinal(){
  const t = TRATAMIENTOS.find(x => x.id === reserva.trat);
  if (!t) return null;
  const base = confirmedTotal ?? t.gs;
  const desc = reserva.pago === 'virtual' ? Math.round(base * 0.05) : 0;
  return { base, desc, total: base - desc };
}

function renderResumen(){
  const t = TRATAMIENTOS.find(x => x.id === reserva.trat);
  const d = reserva.doc ? docPorId(reserva.doc) : null;
  const filas = [];

  if (d) filas.push(['Profesional', d.nombre]);
  if (reserva.esp) filas.push(['Especialidad', espNombre(reserva.esp)]);
  if (t) filas.push(['Tratamiento', t.nombre], ['Duración', t.min + ' minutos']);
  if (reserva.fecha) filas.push(['Fecha', new Date(reserva.fecha + 'T00:00:00').toLocaleDateString('es-PY', { weekday:'long', day:'numeric', month:'long' })]);
  if (reserva.hora) filas.push(['Hora', reserva.hora + ' hs']);
  if (reserva.pago) filas.push(['Pago', reserva.pago === 'virtual' ? 'Virtual anticipado' : 'En el consultorio']);

  $('#resumen-cuerpo').innerHTML = filas.length
    ? filas.map(([k, v]) => `
        <div>
          <p class="text-[11px] text-slate-500 mb-0.5">${k}</p>
          <p class="font-medium leading-snug">${v}</p>
        </div>`).join('')
    : '<p class="text-sm text-slate-500 leading-relaxed">Vas a ver acá el detalle a medida que elijas las opciones.</p>';

  const p = precioFinal();
  const cont = $('#resumen-total');
  if (p){
    cont.classList.remove('hidden');
    cont.innerHTML = `
      ${p.desc ? `
        <div class="flex justify-between text-sm mb-1.5"><span class="text-slate-500">Subtotal</span><span class="text-slate-500">${gs(p.base)}</span></div>
        <div class="flex justify-between text-sm mb-2.5"><span class="text-aqua-700">Descuento pago virtual</span><span class="text-aqua-700">−${gs(p.desc)}</span></div>` : ''}
      <div class="flex justify-between items-baseline">
        <span class="font-display font-700">Total</span>
        <span class="text-right">
          <span class="block font-display font-800 text-lg">${gs(p.total)}</span>
        </span>
      </div>`;
  } else cont.classList.add('hidden');
}

/* ─────────── PASO 5: comprobante ─────────── */
function generarComprobante(){
  const t = TRATAMIENTOS.find(x => x.id === reserva.trat);
  const d = docPorId(reserva.doc);
  const p = precioFinal();
  // Código generado y persistido por el servidor antes de llegar a este paso.

  const fechaLarga = new Date(reserva.fecha + 'T00:00:00').toLocaleDateString('es-PY', { weekday:'long', day:'numeric', month:'long', year:'numeric' });

  $('#comprobante').innerHTML = `
    <div class="bg-navy-900 text-white px-6 py-5 flex items-center justify-between gap-4">
      <div>
        <p class="text-[11px] text-slate-300 mb-0.5">Código de reserva</p>
        <p class="font-mono text-sm sm:text-lg font-semibold break-all mt-2">${reserva.codigo}</p>
      </div>
      <span class="hidden sm:grid w-10 h-10 rounded-xl bg-white/10 place-items-center font-display font-800 text-xs shrink-0">D</span>
    </div>
    <div class="bg-white p-6 space-y-4">
      ${[
        ['Paciente', `${reserva.nombre} ${reserva.apellido}`],
        ['Profesional', `${d.nombre} — ${d.reg}`],
        ['Especialidad', espNombre(reserva.esp)],
        ['Tratamiento', `${t.nombre} (${t.min} min)`],
        ['Fecha y hora', `${fechaLarga}, ${reserva.hora} hs`],
        ['WhatsApp', `${reserva.cod} ${reserva.tel}`],
        ...(reserva.motivo ? [['Nota personal', reserva.motivo]] : [])
      ].map(([k, v]) => `
        <div class="flex flex-wrap justify-between gap-2 pb-4 border-b border-slate-100 last:border-0 last:pb-0">
          <span class="text-sm text-slate-500">${k}</span>
          <span class="text-sm font-medium text-right max-w-[60%] break-words">${escapeHTML(v)}</span>
        </div>`).join('')}
    </div>
    <div class="bg-slate-50 px-6 py-5 border-t border-slate-200">
      <div class="flex justify-between items-baseline mb-1">
        <span class="font-display font-700">Total a abonar</span>
        <span class="font-display font-800 text-xl">${gs(p.total)}</span>
      </div>
      <div class="flex justify-between text-xs text-slate-500">
        <span>${reserva.pago === 'virtual' ? 'Pago virtual anticipado — 5% aplicado' : 'A abonar en el consultorio'}</span>
      </div>
      ${reserva.pago === 'virtual' ? `
        <div class="mt-4 p-3 rounded-xl bg-aqua-50 border border-aqua-100 text-xs text-navy-800 leading-relaxed">
          El pago online todavía no está habilitado.
        </div>` : ''}
    </div>`;
}

function textoComprobante(){
  const t = TRATAMIENTOS.find(x => x.id === reserva.trat);
  const d = docPorId(reserva.doc);
  const p = precioFinal();
  const fechaLarga = new Date(reserva.fecha + 'T00:00:00').toLocaleDateString('es-PY', { weekday:'long', day:'numeric', month:'long', year:'numeric' });
  return [
    CLINIC.name + ' — Comprobante de turno',
    '',
    'Código de reserva: ' + reserva.codigo,
    'Paciente: ' + reserva.nombre + ' ' + reserva.apellido,
    'Profesional: ' + d.nombre + ' (' + d.reg + ')',
    'Especialidad: ' + espNombre(reserva.esp),
    'Tratamiento: ' + t.nombre + ' — ' + t.min + ' min',
    'Fecha: ' + fechaLarga + ', ' + reserva.hora + ' hs',
    'WhatsApp: ' + reserva.cod + ' ' + reserva.tel,
    'Correo: ' + reserva.email,
    ...(reserva.motivo ? ['Nota personal: ' + reserva.motivo] : []),
    '',
    'Modalidad de pago: ' + (reserva.pago === 'virtual' ? 'Virtual anticipado (5% de descuento)' : 'En el consultorio'),
    'Total: ' + gs(p.total),
    '',
    [CLINIC.address, CLINIC.city, CLINIC.phone].filter(Boolean).join(' · '),
    'Reserva registrada. Recordatorios por WhatsApp aún no habilitados.'
  ].join('\n');
}

function copiarComprobante(){
  navigator.clipboard.writeText(textoComprobante())
    .then(() => toast('Detalles copiados al portapapeles.'))
    .catch(() => toast('No se pudo copiar. Probá descargando el comprobante.', 'error'));
}

function descargarComprobante(){
  const blob = new Blob([textoComprobante()], { type:'text/plain;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `turno-${reserva.codigo}.txt`;
  a.click();
  URL.revokeObjectURL(a.href);
  toast('Comprobante descargado.');
}

function reiniciar(){
  if(enviando) return;
  requestId=null; confirmedTotal=null; availabilityVersion++;
  reserva = { modo:null, esp:null, doc:null, trat:null, fecha:null, hora:null, pago:null,
              nombre:'', apellido:'', cod:'+595', tel:'', email:'', motivo:'', codigo:null };
  pasoActual = 1;
  ['#f-nombre','#f-apellido','#f-tel','#f-email','#f-motivo'].forEach(s => { $(s).value = ''; limpiarError($(s)); });
  $('#cuenta-motivo').textContent = '0';
  $$('.modo-btn, .pago-btn').forEach(b => b.setAttribute('aria-pressed', 'false'));
  $('#f-cod').value='+595';
  resetDate();
  mesVista = clinicToday(); mesVista.setDate(1);
  mostrarPaso();
}

function nuevoTurno(){
  reiniciar();
  toast('Listo, empezá una nueva reserva.');
}

/* ═══════════════════════════════════════════════════════════════
   ARRANQUE
   ═══════════════════════════════════════════════════════════════ */

renderStepper();
renderResumen();
irA('inicio');

// contador del textarea
$('#f-motivo').addEventListener('input', e => { $('#cuenta-motivo').textContent = e.target.value.length; });

// limpiar el error del campo en cuanto el paciente lo corrige
['#f-nombre','#f-apellido','#f-tel','#f-email'].forEach(s => $(s).addEventListener('input', e => limpiarError(e.target)));

// sombra del header al hacer scroll
addEventListener('scroll', () => {
  $('#header').classList.toggle('shadow-card', scrollY > 8);
}, { passive:true });

// métricas animadas y aparición de secciones
const io = new IntersectionObserver((entradas) => {
  entradas.forEach(en => {
    if (!en.isIntersecting) return;
    en.target.classList.add('shown');
    const c = en.target.querySelector('.counter');
    if (c && !c.dataset.listo){
      c.dataset.listo = '1';
      const destino = +c.dataset.to, sufijo = c.dataset.suffix || '';
      const reducido = matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (reducido){ c.textContent = destino.toLocaleString('es-PY') + sufijo; return; }
      let inicio = null;
      const animar = (ts) => {
        if (!inicio) inicio = ts;
        const p = Math.min((ts - inicio) / 1100, 1);
        const eased = 1 - Math.pow(1 - p, 3);
        c.textContent = Math.round(destino * eased).toLocaleString('es-PY') + sufijo;
        if (p < 1) requestAnimationFrame(animar);
      };
      requestAnimationFrame(animar);
    }
    io.unobserve(en.target);
  });
}, { threshold:.25 });

$$('.reveal').forEach(el => io.observe(el));
