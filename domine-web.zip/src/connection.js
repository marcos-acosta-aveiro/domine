async function api(path, options={}) {
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),15000);
  try {
    const response=await fetch(path,{...options,signal:controller.signal});
    const data=await response.json();
    if(!response.ok){ const error=new Error(data.error || 'No pudimos completar la operación.'); error.status=response.status; throw error; }
    return data;
  } catch(error) {
    if(error.status) throw error;
    throw new Error('No pudimos conectar. Revisá tu conexión e intentá nuevamente.');
  } finally { clearTimeout(timer); }
}

async function loadCatalog(){
  $('#catalog-status').innerHTML='<span role="status">Cargando especialidades y profesionales…</span>';
  $('#btn-siguiente').disabled=true;
  try {
    const [data,configuration]=await Promise.all([api('/api/catalog'),api('/api/clinic')]);
    CLINIC=configuration;
    if(!data.specialties.length || !data.professionals.length || !data.services.length) throw new Error('El catálogo todavía no está disponible.');
    ESPECIALIDADES=data.specialties; DOCTORES=data.professionals; TRATAMIENTOS=data.services;
    $('#catalog-status').classList.add('hidden');
    $$('.modo-btn').forEach(b=>b.disabled=false);
    renderEspecialidades(); renderFiltros(); renderDoctores();
    if(typeof applyClinic==='function') applyClinic();
    $$('.reveal').forEach(el=>io.observe(el));
    actualizarBotonSiguiente(); renderHeroSlots();
  } catch(error) {
    $('#catalog-status').classList.remove('hidden');
    $('#catalog-status').innerHTML=`<span role="alert">${escapeHTML(error.message)}</span> <button onclick="loadCatalog()" class="underline font-semibold">Reintentar</button>`;
    $('#hero-slots').textContent='No pudimos cargar la agenda.';
    $$('.modo-btn').forEach(b=>b.disabled=true);
  }
}

async function renderHeroSlots(){
  const today=localISO(clinicToday());
  $('#hero-fecha').textContent='Hoy · Asunción';
  $('#hero-slots').innerHTML='<p role="status" class="text-sm text-slate-500">Consultando la agenda…</p>';
  try {
    const samples=await Promise.all(DOCTORES.slice(0,3).map(async ({id})=>{
      const doc=docPorId(id), service=TRATAMIENTOS.find(t=>t.docs.includes(id));
      if(!doc || !service) return null;
      const result=await api('/api/availability?'+new URLSearchParams({doc:id,trat:service.id,fecha:today}));
      return result.slots.length ? {doc,service,hora:result.slots[0]} : null;
    }));
    $('#hero-slots').innerHTML=samples.filter(Boolean).map(({doc,service,hora})=>`
      <button onclick="atajoHorario('${doc.id}','${service.id}','${today}','${hora}')" class="w-full flex items-center gap-3 p-3 rounded-xl border border-slate-200 hover:border-aqua-600 hover:bg-aqua-50 transition-colors text-left">
        <img src="${doc.foto}" alt="" width="40" height="40" class="w-10 h-10 rounded-full object-cover">
        <span class="flex-1 min-w-0"><span class="block font-medium text-sm truncate">${escapeHTML(doc.nombre)}</span><span class="block text-xs text-slate-500">${escapeHTML(service.nombre)}</span></span>
        <span class="font-display font-700 text-sm text-aqua-700">${hora}</span>
      </button>`).join('') || '<p class="text-sm text-slate-600 py-4">No quedan turnos para hoy en estas especialidades. Consultá las próximas fechas.</p>';
  } catch {
    $('#hero-slots').innerHTML='<p class="text-sm text-slate-600">No pudimos consultar la agenda.</p><button onclick="renderHeroSlots()" class="mt-2 text-sm underline">Reintentar</button>';
  }
}

function atajoHorario(doc,trat,fecha,hora){
  reiniciar(); reserva={...reserva,modo:'profesional',esp:docPorId(doc).esp,doc,trat,fecha,hora};
  irA('agendar'); pasoActual=3; mostrarPaso();
}

async function confirmarReserva(){
  if(enviando) return;
  const payload={doc:reserva.doc,trat:reserva.trat,fecha:reserva.fecha,hora:reserva.hora,pago:reserva.pago,nombre:reserva.nombre,apellido:reserva.apellido,cod:reserva.cod,tel:reserva.tel,email:reserva.email};
  const fingerprint=JSON.stringify(payload);
  if(!requestId || requestFingerprint!==fingerprint){ requestId=crypto.randomUUID(); requestFingerprint=fingerprint; }
  enviando=true;
  $('#btn-siguiente').disabled=true; $('#btn-siguiente').textContent='Guardando tu turno…';
  $('#wizard').setAttribute('aria-busy','true');
  $$('#paso-4 input, #paso-4 select, #paso-4 button, #paso-4 textarea, #btn-atras, #stepper button').forEach(el=>el.disabled=true);
  try {
    const result=await api('/api/appointments',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...payload,requestId})});
    reserva.codigo=result.code; confirmedTotal=result.total;
    pasoActual=5; mostrarPaso(); renderHeroSlots();
  } catch(error) {
    toast(error.message,'error');
    if(error.status===409){ reserva.hora=null; requestId=null; pasoActual=3; mostrarPaso(); }
  } finally {
    enviando=false; $('#wizard').removeAttribute('aria-busy');
    $$('#paso-4 input, #paso-4 select, #paso-4 button, #paso-4 textarea, #btn-atras').forEach(el=>{if(el.dataset.pago!=='virtual') el.disabled=false;});
    $('#btn-siguiente').textContent=pasoActual===4?'Confirmar turno':'Continuar';
    renderStepper(); actualizarBotonSiguiente();
  }
}

$$('.nav-tab').forEach((button,index)=>button.addEventListener('keydown',event=>{
  if(event.ctrlKey||event.metaKey||event.altKey)return;
  if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
  event.preventDefault();
  const tabs=$$('.nav-tab');
  const next=event.key==='Home'?0:event.key==='End'?tabs.length-1:(index+(event.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;
  irA(tabs[next].id.slice(4)); tabs[next].focus();
}));
loadCatalog();
