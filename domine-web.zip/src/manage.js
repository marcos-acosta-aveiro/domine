import {InputError,clinicClock} from './booking.js';
import {readBody} from './http.js';
import {clinic} from '../config/clinic.js';
const time=min=>`${String(Math.floor(min/60)).padStart(2,'0')}:${String(min%60).padStart(2,'0')}`;

export function canChange(row,env={},date=new Date()){
  if(row.status!=='confirmed') return false;
  const now=clinicClock(date);
  const minutes=(Date.parse(row.date)-Date.parse(now.date))/60000+row.start_min-now.minute-date.getUTCSeconds()/60-date.getUTCMilliseconds()/60000;
  return minutes>0 && minutes>=clinic.changeNoticeHours*60;
}

async function details(env,row){
  const doc=await env.DB.prepare('SELECT data FROM professionals WHERE tenant_id=? AND id=?').bind(env.TENANT_ID,row.professional_id).first();
  const service=await env.DB.prepare('SELECT data FROM services WHERE tenant_id=? AND id=?').bind(env.TENANT_ID,row.service_id).first();
  const events=await env.DB.prepare('SELECT kind,previous_date,previous_start,date,start_min,created_at FROM appointment_events WHERE tenant_id=? AND appointment_code=? ORDER BY id DESC').bind(env.TENANT_ID,row.code).all();
  const patient=JSON.parse(row.patient_json);
  return {appointment:{code:row.code,date:row.date,hora:time(row.start_min),duration:row.end_min-row.start_min,total:row.price,status:row.status,version:row.version,patientName:patient.nombre+' '+patient.apellido,professional:JSON.parse(doc.data),service:JSON.parse(service.data),canChange:canChange(row,env)},history:events.results.map(e=>({...e,hora:time(e.start_min),previous_hora:e.previous_start===null?null:time(e.previous_start)})),noticeHours:clinic.changeNoticeHours};
}

export async function manage(request,env,action,availability){
  if(!['lookup','availability','reschedule','cancel'].includes(action)) throw new InputError('Ruta no encontrada.',404);
  const body=await readBody(request);
  const code=typeof body.code==='string'?body.code.trim().toUpperCase():'';
  const email=typeof body.email==='string'?body.email.trim().toLowerCase():'';
  if(!/^(SL|DM)-[A-F0-9]{32}$/.test(code) || email.length>254 || !email) throw new InputError('No encontramos una reserva con ese código y correo.',404);
  const row=await env.DB.prepare('SELECT * FROM appointments WHERE tenant_id=? AND code=?').bind(env.TENANT_ID,code).first();
  if(!row || JSON.parse(row.patient_json).email.toLowerCase()!==email) throw new InputError('No encontramos una reserva con ese código y correo.',404);
  if(action==='lookup') return details(env,row);
  const kind=action==='cancel'?'cancel':'reschedule';
  if(action!=='availability'){
    if(!Number.isSafeInteger(body.version) || typeof body.operationId!=='string' || !/^[0-9a-f-]{36}$/.test(body.operationId)) throw new InputError('Revisá la reserva y volvé a intentarlo.');
    if(row.last_operation_id===body.operationId && row.last_operation_kind===kind) return details(env,row);
    if(row.version!==body.version) throw new InputError('Tu reserva cambió en otra ventana. Actualizala antes de continuar.',409);
  }
  if(!canChange(row,env)) throw new InputError('Esta reserva ya no admite cambios online. Consultá su estado actualizado.',409);
  if(action==='availability'){
    const result=await availability(env,row.professional_id,row.service_id,body.fecha,row.code);
    return {slots:result.slots,duration:result.service.duration};
  }
  let sql,args;
  if(action==='cancel'){
    sql="UPDATE appointments SET status='cancelled',version=version+1,last_operation_id=?,last_operation_kind='cancel' WHERE tenant_id=? AND code=? AND version=? AND status='confirmed'";
    args=[body.operationId,env.TENANT_ID,code,body.version];
  } else {
    if(typeof body.hora!=='string' || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(body.hora)) throw new InputError('Elegí un horario válido.');
    const result=await availability(env,row.professional_id,row.service_id,body.fecha,row.code);
    if(!result.slots.includes(body.hora)) throw new InputError('Ese horario ya no está disponible. Tu turno original sigue reservado.',409);
    const [hours,minutes]=body.hora.split(':').map(Number), start=hours*60+minutes;
    if(body.fecha===row.date && start===row.start_min) throw new InputError('Elegí una fecha u hora diferente a la actual.');
    sql="UPDATE appointments SET date=?,start_min=?,end_min=?,version=version+1,last_operation_id=?,last_operation_kind='reschedule' WHERE tenant_id=? AND code=? AND version=? AND status='confirmed'";
    args=[body.fecha,start,start+result.service.duration,body.operationId,env.TENANT_ID,code,body.version];
  }
  try{await env.DB.prepare(sql).bind(...args).run();}
  catch(error){if(String(error.message).includes('SLOT_CONFLICT')) throw new InputError('Otro paciente tomó ese horario. Tu turno original sigue reservado.',409);throw error;}
  const changed=await env.DB.prepare('SELECT * FROM appointments WHERE tenant_id=? AND code=?').bind(env.TENANT_ID,code).first();
  if(changed.last_operation_id!==body.operationId) throw new InputError('Tu reserva cambió en otra ventana. Actualizala antes de continuar.',409);
  return details(env,changed);
}
