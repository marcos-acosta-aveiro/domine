const arrowIcon='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg>';
let managed=null, manageAuth=null, selectedNewDate='', selectedNewTime='', slotRequest=0, changeOperation=null, lastWaitToken='';
window.portalBusy=false;
const dateLabel=(date,options={weekday:'long',day:'numeric',month:'long'})=>new Date(date+'T12:00:00').toLocaleDateString('es-PY',options);
const privatePost=(path,data)=>api(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});

function applyClinic(){
  document.title=CLINIC.name+' · Reservas y atención';
  $$('[data-clinic]').forEach(el=>el.textContent=CLINIC[el.dataset.clinic]||'');
  for(const [name,value] of [['--ink',CLINIC.primaryColor],['--accent',CLINIC.accentColor]]) if(/^#[0-9a-f]{6}$/i.test(value)) document.documentElement.style.setProperty(name,value);
  $('#demo-notice').classList.toggle('hidden',!CLINIC.demo);
  if(/^https:\/\//.test(CLINIC.heroImage)){ $('#hero-image').src=CLINIC.heroImage; $('#hero-image').alt=CLINIC.heroImageAlt; }
  $('#clinic-address').textContent=CLINIC.address||'';
  $('#clinic-hours').innerHTML=(CLINIC.hours||[]).map(h=>`<p>${escapeHTML(h)}</p>`).join('');
  $('#clinic-contact').replaceChildren();
  for(const [text,href] of [[CLINIC.phone,'tel:'+String(CLINIC.phone||'').replace(/[^+\d]/g,'')],[CLINIC.email,'mailto:'+CLINIC.email]]){
    if(!text) continue; const a=document.createElement('a');a.textContent=text;a.href=href;a.className='footer-link block';$('#clinic-contact').append(a);
  }
  $('#wait-doc').innerHTML='<option value="">Elegí un profesional</option>'+DOCTORES.map(d=>`<option value="${d.id}">${escapeHTML(d.nombre)} · ${escapeHTML(espNombre(d.esp))}</option>`).join('');
  const today=localISO(clinicToday()), end=clinicToday();end.setDate(end.getDate()+90);
  ['#wait-from','#wait-to'].forEach(id=>{$(id).min=today;$(id).max=localISO(end);});
  $('#wait-from').value=today;
  $('#whatsapp-status').textContent=CLINIC.whatsappEnabled?'Los avisos se enviarán al WhatsApp que indiques, si se libera un horario compatible.':'La lista se guarda. Los avisos por WhatsApp todavía no están habilitados en esta demostración.';
  const params=new URLSearchParams(location.hash.slice(1));
  if(params.has('leave')){irA('espera');abrirBajaEspera();$('#leave-token').value=params.get('leave');history.replaceState(null,'',location.pathname);}
  const doc=params.get('doc'),trat=params.get('trat'),fecha=params.get('fecha');
  if(params.get('view')==='agendar' && DOCTORES.some(d=>d.id===doc) && TRATAMIENTOS.some(t=>t.id===trat&&t.docs.includes(doc))){
    reiniciar();reserva={...reserva,modo:'profesional',doc,trat,esp:docPorId(doc).esp};
    if(/^\d{4}-\d{2}-\d{2}$/.test(fecha||'') && fecha>=today && fecha<=localISO(end)){reserva.fecha=fecha;mesVista=new Date(fecha+'T12:00:00');mesVista.setDate(1);}
    irA('agendar');pasoActual=3;mostrarPaso();
  }
}

function showInfo(html){$('#info-content').innerHTML=html;$('#info-dialog').showModal();}
function mostrarAyuda(){showInfo(`<h2>Te acompañamos paso a paso.</h2><p><strong>Para reservar:</strong> elegí una especialidad o profesional, un servicio y un horario. Completá tus datos y guardá el código que recibís al confirmar.</p><p><strong>Para cambiar o cancelar:</strong> entrá a «Mi turno» con ese código y tu correo. Tenés que hacerlo al menos 6 horas antes.</p><p><strong>Si no hay lugar:</strong> anotate en la lista de espera. Elegís las fechas y si querés recibir avisos.</p><div class="dialog-actions"><button class="btn btn-primary" onclick="$('#info-dialog').close();irA('agendar')">Reservar un turno</button><button class="btn btn-secondary" onclick="$('#info-dialog').close();irA('gestionar')">Ir a mi turno</button></div>`);}
function mostrarPrivacidad(){showInfo(`<h2>Tus datos, con un propósito.</h2><p>Usamos nombre, correo y teléfono para identificar tu reserva. No solicitamos una historia clínica. La nota opcional del formulario solo se incluye en tu comprobante.</p><p>Tu código y correo permiten gestionar la cita. No los compartas. Los permisos para avisos de disponibilidad e invitaciones futuras se eligen por separado y se pueden retirar con el código privado de la lista.</p><p>${CLINIC.demo?'Esta es una demostración: usá datos ficticios. La clínica deberá publicar su aviso de privacidad y contacto antes de habilitar atención real.':'Consultá a la clínica sobre acceso, corrección o eliminación de tus datos.'}</p>`);}

async function lookupAppointment(event){
  event?.preventDefault();if(window.portalBusy)return;
  manageAuth={code:$('#lookup-code').value.trim(),email:$('#lookup-email').value.trim()};
  $('#lookup-error').textContent='';
  const button=$('#lookup-form button[type=submit]');button.disabled=true;button.textContent='Buscando tu turno…';
  window.portalBusy=true;
  try{managed=await privatePost('/api/manage/lookup',manageAuth);renderManaged();}
  catch(error){$('#lookup-error').textContent=error.message;}
  finally{window.portalBusy=false;button.disabled=false;button.innerHTML='Consultar mi turno '+arrowIcon;}
}
$('#lookup-form').addEventListener('submit',lookupAppointment);
function gestionarReservaActual(){
  irA('gestionar');$('#lookup-code').value=reserva.codigo||'';$('#lookup-email').value=reserva.email||'';
  if(reserva.codigo) lookupAppointment();
}
function anotherLookup(){if(window.portalBusy)return;managed=null;manageAuth=null;slotRequest++;$('#managed-appointment').classList.add('hidden');$('.manage-layout').classList.remove('hidden');$('#lookup-code').value='';$('#lookup-email').value='';$('#lookup-code').focus();}

function renderManaged(){
  const a=managed.appointment,cancelled=a.status==='cancelled';
  $('.manage-layout').classList.add('hidden');const container=$('#managed-appointment');container.classList.remove('hidden');
  const date=new Date(a.date+'T12:00:00');
  const status={confirmed:'Turno confirmado',cancelled:'Turno cancelado',attended:'Consulta realizada',no_show:'Turno finalizado'}[a.status]||'Turno';
  container.innerHTML=`<div class="appointment-toolbar"><h2 tabindex="-1" id="managed-heading">Hola, ${escapeHTML(a.patientName.split(' ')[0])}.</h2><button class="text-action" onclick="anotherLookup()">Consultar otra reserva</button></div><p id="manage-message" class="form-error" role="status"></p><div class="appointment-layout"><div><section class="appointment-card"><span class="appointment-status ${cancelled?'cancelled':''}"><span class="status-dot"></span>${status}</span><div class="appointment-date"><div class="date-tile"><b>${date.getDate()}</b><span>${date.toLocaleDateString('es-PY',{month:'short'})}</span></div><div><h2>${escapeHTML(dateLabel(a.date,{weekday:'long',day:'numeric',month:'long'}))}</h2><p>${a.hora} h · ${a.duration} minutos · Hora de Asunción</p></div></div><dl class="appointment-details"><div><dt>Profesional</dt><dd>${escapeHTML(a.professional.nombre)}</dd></div><div><dt>Servicio</dt><dd>${escapeHTML(a.service.nombre)}</dd></div><div><dt>Paciente</dt><dd>${escapeHTML(a.patientName)}</dd></div><div><dt>Importe en consultorio</dt><dd>${gs(a.total)}</dd></div></dl><p class="private-code">Código privado de tu reserva<code>${escapeHTML(a.code)}</code></p><div class="appointment-actions">${a.canChange?'<button class="btn btn-primary" onclick="openReschedule()">Elegir otro horario '+arrowIcon+'</button>':''}${!cancelled?'<button class="btn btn-secondary" onclick="downloadCalendar()">Guardar en mi calendario</button>':''}<button class="btn btn-secondary" onclick="downloadManagedReceipt()">Descargar comprobante</button></div>${a.canChange?'<button class="cancel-link" onclick="askCancellation()">No voy a asistir: cancelar turno</button>':''}<p class="policy-note">${cancelled?'Tu turno está cancelado y el horario quedó disponible para otra persona.':a.canChange?'Podés cambiar o cancelar hasta 6 horas antes. Tu código seguirá siendo el mismo.':'Este turno ya no admite cambios online. El plazo para hacerlo es de 6 horas antes.'}</p>${cancelled?'<button class="btn btn-primary" onclick="irA(\'agendar\')">Reservar un nuevo turno</button>':''}</section><section id="reschedule-panel" class="surface reschedule-panel hidden"></section></div><aside class="history-panel"><h2>Historia de tu turno</h2><ol>${managed.history.map(e=>`<li><h3>${{created:'Reserva creada',rescheduled:'Horario actualizado',cancelled:'Reserva cancelada'}[e.kind]}</h3><p>${escapeHTML(dateLabel(e.date))} · ${e.hora} h</p>${e.kind==='rescheduled'?`<p>Antes: ${escapeHTML(dateLabel(e.previous_date))} · ${e.previous_hora} h</p>`:''}<time>${new Date(e.created_at.replace(' ','T')+'Z').toLocaleDateString('es-PY',{day:'numeric',month:'short',year:'numeric'})}</time></li>`).join('')}</ol><p class="small-note">Los cambios se guardan junto a tu reserva.</p></aside></div>`;
  $('#managed-heading').focus({preventScroll:true});
}

function openReschedule(){
  if(window.portalBusy)return; selectedNewDate='';selectedNewTime='';changeOperation=null;slotRequest++;
  const end=clinicToday();end.setDate(end.getDate()+90);
  const panel=$('#reschedule-panel');panel.classList.remove('hidden');
  panel.innerHTML=`<h2 tabindex="-1">Elegí un nuevo momento.</h2><p>El mismo profesional y servicio. Tu turno original se mantiene hasta que confirmes.</p><div class="reschedule-grid"><div><label for="new-date">Nueva fecha</label><input type="date" id="new-date" min="${localISO(clinicToday())}" max="${localISO(end)}"><p class="small-note">Horarios de Asunción.</p></div><div><label>Horarios disponibles</label><div id="new-slots"><p class="small-note">Elegí una fecha para consultar la agenda.</p></div></div></div><p class="form-error" id="reschedule-error" role="alert"></p><div id="reschedule-review"></div>`;
  $('#new-date').addEventListener('change',loadNewSlots);panel.querySelector('h2').focus({preventScroll:true});panel.scrollIntoView({behavior:motionBehavior(),block:'start'});
}
async function loadNewSlots(){
  if(window.portalBusy)return;
  const fecha=$('#new-date').value;selectedNewDate=fecha;selectedNewTime='';changeOperation=null;$('#reschedule-review').innerHTML='';$('#reschedule-error').textContent='';
  const seq=++slotRequest;if(!fecha){$('#new-slots').textContent='Elegí una fecha.';return;}
  $('#new-slots').innerHTML='<p role="status" class="small-note">Buscando horarios disponibles…</p>';
  try{
    const result=await privatePost('/api/manage/availability',{...manageAuth,fecha});
    if(seq!==slotRequest)return;
    $('#new-slots').innerHTML=result.slots.length?`<div class="reschedule-slots">${result.slots.map(h=>{const current=fecha===managed.appointment.date&&h===managed.appointment.hora;return `<button type="button" ${current?'disabled title="Tu horario actual" class="slot-current"':''} aria-pressed="false" onclick="selectNewTime('${h}')">${h}</button>`;}).join('')}</div>`:'<p class="small-note" role="status">No hay horarios disponibles ese día. Probá otra fecha.</p>';
  }catch(error){if(seq===slotRequest){$('#new-slots').innerHTML='<button class="text-action" onclick="loadNewSlots()">Volver a consultar horarios</button>';$('#reschedule-error').textContent=error.message;}}
}
function selectNewTime(hora){
  if(window.portalBusy)return;
  selectedNewTime=hora;changeOperation=null;
  $$('#new-slots button').forEach(b=>b.setAttribute('aria-pressed',b.textContent===hora));
  const a=managed.appointment;
  $('#reschedule-review').innerHTML=`<div class="reschedule-review"><div><small>Tu turno actual</small><strong>${escapeHTML(dateLabel(a.date))}<br>${a.hora} h</strong></div>${arrowIcon}<div><small>Tu nuevo turno</small><strong>${escapeHTML(dateLabel(selectedNewDate))}<br>${hora} h</strong></div></div><div class="reschedule-confirm"><button class="btn btn-primary" id="confirm-reschedule" onclick="confirmReschedule()">Confirmar nuevo horario</button><button class="btn btn-secondary" onclick="closeReschedule()">Conservar mi turno actual</button></div>`;
}
function closeReschedule(){if(window.portalBusy)return;$('#reschedule-panel').classList.add('hidden');slotRequest++;$('.appointment-actions button')?.focus({preventScroll:true});}
async function confirmReschedule(){
  if(window.portalBusy||!selectedNewTime)return;
  let failed=false;
  changeOperation ||= crypto.randomUUID();window.portalBusy=true;$('#reschedule-panel').classList.add('form-loading');$('#reschedule-panel').inert=true;$('#confirm-reschedule').textContent='Confirmando el cambio…';$('#reschedule-error').textContent='';
  try{
    managed=await privatePost('/api/manage/reschedule',{...manageAuth,fecha:selectedNewDate,hora:selectedNewTime,version:managed.appointment.version,operationId:changeOperation});
    renderManaged();toast('Tu turno fue reagendado. El cambio ya está guardado.');renderHeroSlots();
  }catch(error){
    failed=true;
    $('#reschedule-error').textContent=error.message;
    if(error.status===409){
      try{const fresh=await privatePost('/api/manage/lookup',manageAuth);if(fresh.appointment.version!==managed.appointment.version){managed=fresh;renderManaged();$('#manage-message').textContent=error.message;}}
      catch{/* La reserva original sigue persistida; el usuario puede volver a consultar. */}
    }
  }finally{window.portalBusy=false;if($('#reschedule-panel')){$('#reschedule-panel').classList.remove('form-loading');$('#reschedule-panel').inert=false;}if($('#confirm-reschedule'))$('#confirm-reschedule').textContent='Confirmar nuevo horario';if(failed){const message=$('#reschedule-error')||$('#manage-message');if(message){message.tabIndex=-1;message.focus({preventScroll:true});}}}
}
function askCancellation(){
  if(window.portalBusy)return;
  showInfo(`<h2>¿Querés cancelar este turno?</h2><p>${escapeHTML(managed.appointment.service.nombre)} · ${escapeHTML(dateLabel(managed.appointment.date))}, ${managed.appointment.hora} h.</p><p>El horario quedará disponible para otra persona. Si solo necesitás cambiarlo, podés reagendar.</p><p id="cancel-error" class="form-error" role="alert"></p><div class="dialog-actions"><button class="btn btn-secondary" onclick="$('#info-dialog').close()">Conservar mi turno</button><button id="confirm-cancel" class="btn btn-danger" onclick="confirmCancellation()">Sí, cancelar el turno</button></div>`);
}
let cancelOperation=null;
async function confirmCancellation(){
  if(window.portalBusy)return;window.portalBusy=true;cancelOperation ||= crypto.randomUUID();
  const button=$('#confirm-cancel');button.disabled=true;button.textContent='Cancelando…';
  try{managed=await privatePost('/api/manage/cancel',{...manageAuth,version:managed.appointment.version,operationId:cancelOperation});$('#info-dialog').close();renderManaged();toast('Turno cancelado. Gracias por avisar.');cancelOperation=null;renderHeroSlots();}
  catch(error){if($('#cancel-error'))$('#cancel-error').textContent=error.message;else toast(error.message,'error');}
  finally{window.portalBusy=false;if(button.isConnected){button.disabled=false;button.textContent='Sí, cancelar el turno';}}
}

function downloadFile(name,content,type){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function downloadManagedReceipt(){const a=managed.appointment;downloadFile('turno-'+a.code+'.txt',[CLINIC.name,a.status==='cancelled'?'TURNO CANCELADO':'COMPROBANTE DE TURNO','Código: '+a.code,'Paciente: '+a.patientName,'Profesional: '+a.professional.nombre,'Servicio: '+a.service.nombre,'Fecha: '+dateLabel(a.date,{day:'numeric',month:'long',year:'numeric'}),'Hora: '+a.hora+' · Asunción','Importe: '+gs(a.total),'Cambios y cancelaciones: al menos 6 horas antes.'].join('\n'),'text/plain;charset=utf-8');}
function downloadCalendar(){
  const a=managed.appointment;if(a.status==='cancelled')return;
  const escape=value=>String(value).replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;');
  const stamp=new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'');
  const start=a.date.replaceAll('-','')+'T'+a.hora.replace(':','')+'00';
  const endDate=new Date(a.date+'T'+a.hora+':00Z');endDate.setUTCMinutes(endDate.getUTCMinutes()+a.duration);
  const end=endDate.toISOString().slice(0,19).replace(/[-:]/g,'');
  downloadFile('consulta.ics',['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Domine//Turnos//ES','BEGIN:VEVENT','UID:'+a.code+'@domine','DTSTAMP:'+stamp,'SEQUENCE:'+a.version,'DTSTART;TZID=America/Asuncion:'+start,'DTEND;TZID=America/Asuncion:'+end,'SUMMARY:'+escape('Consulta · '+a.professional.nombre),'LOCATION:'+escape([CLINIC.name,CLINIC.address,CLINIC.city].filter(Boolean).join(', ')),'DESCRIPTION:'+escape('Consultá o cambiá tu turno en la web de la clínica. Los cambios requieren al menos 6 horas de anticipación.'),'END:VEVENT','END:VCALENDAR',''].join('\r\n'),'text/calendar;charset=utf-8');
}

$('#wait-doc').addEventListener('change',()=>{$('#wait-service').innerHTML='<option value="">Elegí un servicio</option>'+TRATAMIENTOS.filter(t=>t.docs.includes($('#wait-doc').value)).map(t=>`<option value="${t.id}">${escapeHTML(t.nombre)} · ${t.min} min</option>`).join('');});
$('#waitlist-form').addEventListener('submit',async event=>{
  event.preventDefault();if(window.portalBusy)return;window.portalBusy=true;const button=$('#waitlist-form button[type=submit]');button.disabled=true;button.textContent='Guardando solicitud…';$('#wait-error').textContent='';
  try{
    const result=await privatePost('/api/waitlist',{doc:$('#wait-doc').value,trat:$('#wait-service').value,from:$('#wait-from').value,to:$('#wait-to').value,nombre:$('#wait-name').value,apellido:$('#wait-lastname').value,phone:$('#wait-phone').value,email:$('#wait-email').value,consent:$('#wait-consent').checked,reactivation:$('#wait-reactivation').checked});
    lastWaitToken=result.token;
    $('#wait-success').innerHTML=`<div class="notice-success"><strong>Ya estás en la lista.</strong><p>Guardá este código privado para retirar tu solicitud o tus permisos.</p><code>${escapeHTML(result.token)}</code><button type="button" class="text-action" onclick="downloadFile('mi-lista-de-espera.txt',lastWaitToken,'text/plain')">Descargar mi código</button><p>${CLINIC.whatsappEnabled?'Si aparece una oportunidad compatible, podrás recibir un aviso.':'Tu solicitud se guardó. Los envíos de WhatsApp siguen desactivados en esta demo.'}</p></div>`;
    $('#waitlist-form').reset();$('#wait-service').innerHTML='<option value="">Primero elegí un profesional</option>';$('#wait-from').value=localISO(clinicToday());$('#wait-success').scrollIntoView({behavior:motionBehavior(),block:'center'});
  }catch(error){$('#wait-error').textContent=error.message;}
  finally{window.portalBusy=false;button.disabled=false;button.innerHTML='Anotarme en la lista '+arrowIcon;}
});
function abrirBajaEspera(){$('#leave-form').classList.remove('hidden');$('#leave-token').value=lastWaitToken;$('#leave-token').focus();}
$('#leave-form').addEventListener('submit',async event=>{event.preventDefault();const button=$('#leave-form button');button.disabled=true;try{await privatePost('/api/waitlist/leave',{token:$('#leave-token').value.trim()});$('#leave-status').textContent='Solicitud retirada. Ya no recibirás estos avisos ni invitaciones.';}catch(error){$('#leave-status').textContent=error.message;}finally{button.disabled=false;}});
function motionBehavior(){return matchMedia('(prefers-reduced-motion: reduce)').matches||document.body.classList.contains('keyboard-mode')?'instant':'smooth';}
document.addEventListener('keydown',()=>document.body.classList.add('keyboard-mode'),{capture:true});
document.addEventListener('pointerdown',()=>document.body.classList.remove('keyboard-mode'),{capture:true});
$('#info-dialog').addEventListener('cancel',event=>{if(window.portalBusy)event.preventDefault();});
