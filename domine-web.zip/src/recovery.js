const hour=min=>`${String(Math.floor(min/60)).padStart(2,'0')}:${String(min%60).padStart(2,'0')}`;
export async function prepareRecovery(env,availability){
  const jobs=(await env.DB.prepare(`SELECT j.event_id,e.previous_date,e.previous_start,a.professional_id,a.service_id,a.patient_json FROM recovery_jobs j JOIN appointment_events e ON e.id=j.event_id JOIN appointments a ON a.code=e.appointment_code WHERE j.tenant_id=? AND j.status='pending' ORDER BY j.event_id LIMIT 20`).bind(env.TENANT_ID).all()).results;
  let queued=0;
  for(const job of jobs){
    const date=job.previous_date,hora=hour(job.previous_start);
    let available;
    try{available=await availability(env,job.professional_id,job.service_id,date);}catch{await done(env,job,'expired');continue;}
    if(!available.slots.includes(hora)){await done(env,job,'unavailable');continue;}
    const former=JSON.parse(job.patient_json).email;
    // FIFO. The patient releasing the slot is never offered their own vacancy.
    let candidate=await env.DB.prepare(`SELECT * FROM waitlist w WHERE tenant_id=? AND professional_id=? AND service_id=? AND active=1 AND consent=1 AND date_from<=? AND date_to>=? AND email!=? AND NOT EXISTS (SELECT 1 FROM notifications n WHERE n.waitlist_token=w.token AND n.created_at>datetime('now','-7 days') AND n.status IN ('pending','sending','sent','unknown')) ORDER BY created_at,token LIMIT 1`).bind(env.TENANT_ID,job.professional_id,job.service_id,date,date,former).first();
    let purpose='availability';
    if(!candidate){
      // Reactivation only after an attended visit >= 180 days ago and explicit opt-in.
      candidate=await env.DB.prepare(`SELECT w.* FROM waitlist w WHERE w.tenant_id=? AND w.professional_id=? AND w.service_id=? AND w.active=1 AND w.consent=1 AND w.reactivation=1 AND w.email!=? AND EXISTS (SELECT 1 FROM appointments a WHERE a.tenant_id=w.tenant_id AND a.professional_id=w.professional_id AND json_extract(a.patient_json,'$.email')=w.email AND a.status='attended') AND NOT EXISTS (SELECT 1 FROM appointments a WHERE a.tenant_id=w.tenant_id AND json_extract(a.patient_json,'$.email')=w.email AND ((a.status='attended' AND a.date>date('now','-180 days')) OR (a.status='confirmed' AND a.date>=date('now')))) AND NOT EXISTS (SELECT 1 FROM notifications n WHERE n.waitlist_token=w.token AND n.created_at>datetime('now','-30 days') AND n.status IN ('pending','sending','sent','unknown')) ORDER BY w.created_at LIMIT 1`).bind(env.TENANT_ID,job.professional_id,job.service_id,former).first();
      purpose='reactivation';
    }
    if(!candidate){await done(env,job,'no_candidate');continue;}
    // UNIQUE(event_id) keeps one offer per released appointment event.
    await env.DB.prepare('INSERT OR IGNORE INTO notifications(id,event_id,tenant_id,waitlist_token,purpose,date,hora) VALUES(?,?,?,?,?,?,?)').bind(crypto.randomUUID(),job.event_id,env.TENANT_ID,candidate.token,purpose,date,hora).run();
    await done(env,job,'prepared');queued++;
  }
  return {queued};
}
const done=(env,job,status)=>env.DB.prepare('UPDATE recovery_jobs SET status=? WHERE event_id=? AND tenant_id=?').bind(status,job.event_id,env.TENANT_ID).run();

export function whatsappPayload(env,entry){
  const template=entry.purpose==='reactivation'?env.WHATSAPP_REACTIVATION_TEMPLATE:env.WHATSAPP_AVAILABILITY_TEMPLATE;
  if(!template)throw new Error('Missing approved template');
  const site=new URL(env.PUBLIC_URL);if(site.protocol!=='https:')throw new Error('PUBLIC_URL requires HTTPS');
  site.hash=new URLSearchParams({view:'agendar',doc:entry.professional_id,trat:entry.service_id,fecha:entry.date}).toString();
  const leave=new URL(env.PUBLIC_URL);leave.hash=new URLSearchParams({leave:entry.waitlist_token}).toString();
  return {messaging_product:'whatsapp',to:entry.phone.replace('+',''),type:'template',template:{name:template,language:{code:env.WHATSAPP_LANGUAGE||'es'},components:[{type:'body',parameters:[entry.nombre,entry.date,entry.hora,site.href,leave.href].map(text=>({type:'text',text}))}]}};
}

export async function sendNotifications(env,availability,send=fetch){
  if(env.WHATSAPP_ENABLED!=='true')return {disabled:true,sent:0};
  if(!env.WHATSAPP_TOKEN||!env.WHATSAPP_PHONE_ID||!/^v\d+\.\d+$/.test(env.WHATSAPP_API_VERSION||'')||!env.PUBLIC_URL)throw new Error('WhatsApp configuration incomplete');
  const pending=(await env.DB.prepare(`SELECT n.*,w.phone,w.nombre,w.professional_id,w.service_id,w.active,w.consent,w.reactivation FROM notifications n JOIN waitlist w ON w.token=n.waitlist_token WHERE n.tenant_id=? AND n.status='pending' ORDER BY n.created_at LIMIT 10`).bind(env.TENANT_ID).all()).results;
  let sent=0;
  for(const entry of pending){
    const permission=await env.DB.prepare('SELECT active,consent,reactivation FROM waitlist WHERE tenant_id=? AND token=?').bind(env.TENANT_ID,entry.waitlist_token).first();
    if(!permission?.active||!permission.consent||(entry.purpose==='reactivation'&&!permission.reactivation)){await status(env,entry.id,'cancelled');continue;}
    let available;try{available=await availability(env,entry.professional_id,entry.service_id,entry.date);}catch{await status(env,entry.id,'expired');continue;}
    if(!available.slots.includes(entry.hora)){await status(env,entry.id,'unavailable');continue;}
    const payload=whatsappPayload(env,entry);
    const claimed=await env.DB.prepare("UPDATE notifications SET status='sending',updated_at=CURRENT_TIMESTAMP WHERE id=? AND tenant_id=? AND status='pending' RETURNING id").bind(entry.id,env.TENANT_ID).first();
    if(!claimed)continue;
    try{
      const response=await send(`https://graph.facebook.com/${env.WHATSAPP_API_VERSION}/${env.WHATSAPP_PHONE_ID}/messages`,{method:'POST',headers:{Authorization:'Bearer '+env.WHATSAPP_TOKEN,'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(15000)});
      const result=await response.json();
      if(response.ok&&result.messages?.[0]?.id){await env.DB.prepare("UPDATE notifications SET status='sent',provider_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND tenant_id=?").bind(result.messages[0].id,entry.id,env.TENANT_ID).run();sent++;}
      else await status(env,entry.id,'failed');
    }catch{await status(env,entry.id,'unknown');} // Never retry an ambiguous send automatically.
  }
  return {sent};
}
const status=(env,id,state)=>env.DB.prepare('UPDATE notifications SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND tenant_id=?').bind(state,id,env.TENANT_ID).run();
