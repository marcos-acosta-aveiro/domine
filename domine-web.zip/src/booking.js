export class InputError extends Error {
  constructor(message, status = 400) { super(message); this.status = status; }
}

export function clinicClock(now = new Date()) {
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Asuncion', year:'numeric', month:'2-digit', day:'2-digit',
    hour:'2-digit', minute:'2-digit', hourCycle:'h23'
  }).formatToParts(now).map(p => [p.type, p.value]));
  return { date: `${parts.year}-${parts.month}-${parts.day}`, minute: Number(parts.hour)*60 + Number(parts.minute) };
}

export function validateDate(date, now = new Date()) {
  if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new InputError('Elegí una fecha válida.');
  const parsed = new Date(date + 'T12:00:00Z');
  if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0,10) !== date) throw new InputError('La fecha no existe.');
  const today = clinicClock(now).date;
  const days = (Date.parse(date) - Date.parse(today)) / 86400000;
  if (days < 0 || days > 90) throw new InputError('Reservá entre hoy y los próximos 90 días.');
  return date;
}

export function slotsFor(date, duration, schedule, busy, now = new Date()) {
  const clock = clinicClock(now);
  const slots = [];
  for (const interval of schedule) {
    for (let start = interval.start_min; start + duration <= interval.end_min; start += 15) {
      if (date < clock.date || (date === clock.date && start <= clock.minute)) continue;
      if (busy.some(b => start < b.end_min && start + duration > b.start_min)) continue;
      slots.push(`${String(Math.floor(start / 60)).padStart(2,'0')}:${String(start % 60).padStart(2,'0')}`);
    }
  }
  return [...new Set(slots)].sort();
}

export function validatePatient(input) {
  const text = (key, min, max) => {
    const value = input[key];
    if (typeof value !== 'string' || value.trim().length < min || value.trim().length > max || /[\u0000-\u001f]/.test(value)) throw new InputError('Revisá los datos personales.');
    return value.trim();
  };
  const nombre = text('nombre',2,80), apellido = text('apellido',2,80);
  const email = text('email',5,254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw new InputError('Revisá tu correo electrónico.');
  const cod = text('cod',2,4), tel = text('tel',8,24).replace(/[\s()-]/g,'');
  if (!/^\+\d{1,3}$/.test(cod) || !/^\d{8,12}$/.test(tel) || cod.length - 1 + tel.length > 15) throw new InputError('Revisá tu número de WhatsApp.');
  return { nombre, apellido, email, cod, tel };
}
