import {InputError,validateDate} from './booking.js';
import {readBody} from './http.js';
export async function waitlist(request,env,leave=false){
  const body=await readBody(request);
  if(leave){
    if(typeof body.token!=='string'|| !/^[a-f0-9]{32}$/.test(body.token))throw new InputError('Revisá tu código privado.');
    await env.DB.prepare('UPDATE waitlist SET active=0,consent=0,reactivation=0,revoked_at=CURRENT_TIMESTAMP WHERE tenant_id=? AND token=?').bind(env.TENANT_ID,body.token).run();
    return {ok:true};
  }
  if(body.consent!==true)throw new InputError('Necesitamos tu permiso para enviarte avisos de disponibilidad.');
  validateDate(body.from);validateDate(body.to);
  if(body.from>body.to)throw new InputError('La fecha final debe ser igual o posterior a la inicial.');
  const clean=(key,max)=>{if(typeof body[key]!=='string'||body[key].trim().length<2||body[key].length>max)throw new InputError('Revisá tus datos de contacto.');return body[key].trim();};
  const nombre=clean('nombre',80),apellido=clean('apellido',80),email=clean('email',254).toLowerCase();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email))throw new InputError('Revisá tu correo.');
  const phone=clean('phone',25).replace(/[\s()-]/g,'');
  if(!/^\+[1-9]\d{7,14}$/.test(phone))throw new InputError('Ingresá WhatsApp con código de país, por ejemplo +595 981123456.');
  if(typeof body.doc!=='string'||typeof body.trat!=='string')throw new InputError('Elegí un profesional y servicio.');
  const match=await env.DB.prepare('SELECT service_id FROM professional_services WHERE tenant_id=? AND professional_id=? AND service_id=?').bind(env.TENANT_ID,body.doc,body.trat).first();
  if(!match)throw new InputError('El profesional no ofrece ese servicio.');
  const token=crypto.randomUUID().replaceAll('-','');
  try{
    await env.DB.prepare('INSERT INTO waitlist(token,tenant_id,professional_id,service_id,date_from,date_to,nombre,apellido,email,phone,consent,reactivation) VALUES(?,?,?,?,?,?,?,?,?,?,1,?)').bind(token,env.TENANT_ID,body.doc,body.trat,body.from,body.to,nombre,apellido,email,phone,body.reactivation===true?1:0).run();
  }catch(error){if(String(error.message).includes('UNIQUE'))throw new InputError('Ya hay una solicitud para ese WhatsApp y esas fechas. Conservá el código que recibiste al anotarte.',409);throw error;}
  return {token};
}
