import fs from 'node:fs';
fs.mkdirSync('dist',{recursive:true});
fs.copyFileSync('index.html','dist/index.html');
fs.copyFileSync('src/app.js','dist/app.js');
fs.copyFileSync('src/connection.js','dist/connection.js');
fs.copyFileSync('src/_headers','dist/_headers');
fs.copyFileSync('src/portal.js','dist/portal.js');
fs.copyFileSync('src/premium.css','dist/premium.css');
