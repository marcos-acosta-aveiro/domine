// Importación inicial del HTML original. No forma parte del build cotidiano.
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(process.argv[2], 'utf8');
const dataSection=source.slice(source.indexOf('const TC_USD'),source.indexOf('/* ═',source.indexOf('const TESTIMONIOS')));
const data=vm.runInNewContext(dataSection+';({ESPECIALIDADES,DOCTORES,TRATAMIENTOS,TESTIMONIOS})');
const quote=value=>"'"+String(value).replaceAll("'","''")+"'";
let sql="-- Datos ficticios conservados del prototipo original.\nINSERT INTO tenants VALUES ('san-lucas','Clínica San Lucas');\n";
for(const item of data.ESPECIALIDADES) sql+=`INSERT INTO specialties VALUES ('san-lucas',${quote(item.id)},${quote(JSON.stringify(item))});\n`;
for(const item of data.DOCTORES) sql+=`INSERT INTO professionals VALUES ('san-lucas',${quote(item.id)},${quote(item.esp)},${quote(JSON.stringify(item))});\n`;
for(const item of data.TRATAMIENTOS) {
  sql+=`INSERT INTO services VALUES ('san-lucas',${quote(item.id)},${quote(item.esp)},${item.min},${item.gs},${quote(JSON.stringify(item))});\n`;
  for(const doc of item.docs) sql+=`INSERT INTO professional_services VALUES ('san-lucas',${quote(doc)},${quote(item.id)});\n`;
}
for(const doc of data.DOCTORES) {
  for(let day=1;day<=5;day++) for(const [start,end] of [[450,720],[840,1140]]) sql+=`INSERT INTO schedules VALUES ('san-lucas',${quote(doc.id)},${day},${start},${end});\n`;
  sql+=`INSERT INTO schedules VALUES ('san-lucas',${quote(doc.id)},6,480,750);\n`;
}
fs.mkdirSync('migrations',{recursive:true}); fs.writeFileSync('migrations/0002_demo.sql',sql);
const config=source.match(/tailwind.config = ([\s\S]*?)<\/script>/)[1];
fs.writeFileSync('tailwind.config.cjs', 'module.exports = '+config.trim().replace(/}\s*$/,", content: ['./index.html','./src/**/*.js'] }")+';\n');
fs.mkdirSync('src',{recursive:true});
fs.writeFileSync('src/styles.css','@tailwind base;\n@tailwind components;\n@tailwind utilities;\n'+source.match(/<style>([\s\S]*?)<\/style>/)[1]);
let app=source.slice(source.lastIndexOf('<script>')+8,source.lastIndexOf('</script>'));
app=app.replace(dataSection,`const TC_USD=7300; // Referencia ilustrativa, no cotización actual.\nlet ESPECIALIDADES=[], DOCTORES=[], TRATAMIENTOS=[];\nconst TESTIMONIOS=${JSON.stringify(data.TESTIMONIOS)};\n`);
fs.writeFileSync('src/app.js',app);
let html=source.replace(/<script src="https:\/\/cdn.tailwindcss.com"><\/script>\s*<script>[\s\S]*?<\/script>/,'<link rel="stylesheet" href="/styles.css">').replace(/<style>[\s\S]*?<\/style>/,'');
html=html.slice(0,html.lastIndexOf('<script>'))+'<script src="/app.js" defer></script>\n</body>\n</html>\n';
fs.writeFileSync('index.html',html);
