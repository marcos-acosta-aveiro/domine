module.exports = {
  theme: {
    extend: {
      colors: {
        navy:  { 950:'#061424', 900:'#0A1C2E', 800:'#13324F', 700:'#1C4A70', 600:'#2A6494' },
        aqua:  { 700:'#0E7490', 600:'#0891B2', 500:'#14B8A6', 100:'#CCFBF1', 50:'#ECFEFF' }
      },
      fontFamily: {
        display: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
        sans: ['Inter', 'system-ui', 'sans-serif']
      },
      fontWeight: { 500:'500', 600:'600', 700:'700', 800:'800' },
      boxShadow: {
        card: '0 1px 2px rgba(10,28,46,.04), 0 8px 24px -8px rgba(10,28,46,.10)',
        lift: '0 2px 4px rgba(10,28,46,.06), 0 18px 40px -12px rgba(10,28,46,.18)'
      }
    }
  }
, content: ['./index.html','./src/**/*.js'] };
