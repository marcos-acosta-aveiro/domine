// Editá este archivo para adaptar la plantilla a tu primer cliente.
// No contiene secretos ni datos de pacientes. Se entrega al navegador.
export const clinic = {
  name: 'Clínica Dómine',
  shortName: 'Dómine',
  tagline: 'Un espacio para cuidar de vos.',
  description: 'Encontrá tu especialista, reservá un turno y organizá tu atención desde un solo lugar.',
  city: 'Asunción, Paraguay',
  address: '',
  phone: '',
  email: '',
  timezone: 'America/Asuncion',
  primaryColor: '#173D43',
  accentColor: '#176B56',
  demo: true,
  changeNoticeHours: 6,
  heroImage: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=1100&q=85',
  heroImageAlt: 'Profesional de salud en un entorno de consulta',
  hours: ['Lunes a viernes · 07:30–12:00 y 14:00–19:00', 'Sábados · 08:00–12:30', 'Domingos · Cerrado']
};
