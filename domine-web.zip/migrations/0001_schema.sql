PRAGMA foreign_keys = ON;
CREATE TABLE tenants (id TEXT PRIMARY KEY, name TEXT NOT NULL);
CREATE TABLE specialties (tenant_id TEXT NOT NULL REFERENCES tenants(id), id TEXT NOT NULL, data TEXT NOT NULL, PRIMARY KEY(tenant_id,id));
CREATE TABLE professionals (tenant_id TEXT NOT NULL, id TEXT NOT NULL, specialty_id TEXT NOT NULL, data TEXT NOT NULL, PRIMARY KEY(tenant_id,id), FOREIGN KEY(tenant_id,specialty_id) REFERENCES specialties(tenant_id,id));
CREATE TABLE services (tenant_id TEXT NOT NULL, id TEXT NOT NULL, specialty_id TEXT NOT NULL, duration INTEGER NOT NULL CHECK(duration BETWEEN 15 AND 240), price INTEGER NOT NULL CHECK(price >= 0), data TEXT NOT NULL, PRIMARY KEY(tenant_id,id), FOREIGN KEY(tenant_id,specialty_id) REFERENCES specialties(tenant_id,id));
CREATE TABLE professional_services (tenant_id TEXT NOT NULL, professional_id TEXT NOT NULL, service_id TEXT NOT NULL, PRIMARY KEY(tenant_id,professional_id,service_id), FOREIGN KEY(tenant_id,professional_id) REFERENCES professionals(tenant_id,id), FOREIGN KEY(tenant_id,service_id) REFERENCES services(tenant_id,id));
CREATE TABLE schedules (tenant_id TEXT NOT NULL, professional_id TEXT NOT NULL, weekday INTEGER NOT NULL CHECK(weekday BETWEEN 0 AND 6), start_min INTEGER NOT NULL, end_min INTEGER NOT NULL, CHECK(start_min >= 0 AND end_min <= 1440 AND start_min < end_min), PRIMARY KEY(tenant_id,professional_id,weekday,start_min), FOREIGN KEY(tenant_id,professional_id) REFERENCES professionals(tenant_id,id));
CREATE TABLE blocks (id INTEGER PRIMARY KEY, tenant_id TEXT NOT NULL, professional_id TEXT NOT NULL, date TEXT NOT NULL, start_min INTEGER NOT NULL DEFAULT 0, end_min INTEGER NOT NULL DEFAULT 1440, CHECK(start_min >= 0 AND end_min <= 1440 AND start_min < end_min), FOREIGN KEY(tenant_id,professional_id) REFERENCES professionals(tenant_id,id));
CREATE INDEX blocks_date ON blocks(tenant_id,professional_id,date);
CREATE TABLE appointments (
  code TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  request_id TEXT NOT NULL,
  professional_id TEXT NOT NULL,
  service_id TEXT NOT NULL,
  date TEXT NOT NULL,
  start_min INTEGER NOT NULL,
  end_min INTEGER NOT NULL,
  patient_json TEXT NOT NULL,
  price INTEGER NOT NULL CHECK(price >= 0),
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK(payment_status IN ('pending','paid','refunded')),
  status TEXT NOT NULL DEFAULT 'confirmed' CHECK(status IN ('confirmed','cancelled','attended','no_show')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(tenant_id,request_id),
  CHECK(start_min >= 0 AND end_min <= 1440 AND start_min < end_min),
  FOREIGN KEY(tenant_id,professional_id,service_id) REFERENCES professional_services(tenant_id,professional_id,service_id)
);
CREATE INDEX appointments_agenda ON appointments(tenant_id,professional_id,date,status);
-- SQLite executes the check and insert atomically: two simultaneous requests cannot overlap.
CREATE TRIGGER prevent_overlap_insert BEFORE INSERT ON appointments WHEN NEW.status != 'cancelled'
BEGIN
  SELECT RAISE(ABORT, 'SLOT_CONFLICT') WHERE EXISTS (
    SELECT 1 FROM appointments WHERE tenant_id=NEW.tenant_id AND professional_id=NEW.professional_id AND date=NEW.date AND status!='cancelled' AND start_min<NEW.end_min AND end_min>NEW.start_min
  );
END;
CREATE TRIGGER prevent_overlap_update BEFORE UPDATE ON appointments WHEN NEW.status != 'cancelled'
BEGIN
  SELECT RAISE(ABORT, 'SLOT_CONFLICT') WHERE EXISTS (
    SELECT 1 FROM appointments WHERE code!=OLD.code AND tenant_id=NEW.tenant_id AND professional_id=NEW.professional_id AND date=NEW.date AND status!='cancelled' AND start_min<NEW.end_min AND end_min>NEW.start_min
  );
END;
