ALTER TABLE appointments ADD COLUMN version INTEGER NOT NULL DEFAULT 1;
ALTER TABLE appointments ADD COLUMN last_operation_id TEXT;
ALTER TABLE appointments ADD COLUMN last_operation_kind TEXT;
CREATE TABLE appointment_events (
  id INTEGER PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  appointment_code TEXT NOT NULL REFERENCES appointments(code),
  kind TEXT NOT NULL CHECK(kind IN ('created','rescheduled','cancelled')),
  previous_date TEXT,
  previous_start INTEGER,
  date TEXT NOT NULL,
  start_min INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX appointment_events_code ON appointment_events(tenant_id,appointment_code,id);
INSERT INTO appointment_events(tenant_id,appointment_code,kind,date,start_min,created_at)
SELECT tenant_id,code,'created',date,start_min,created_at FROM appointments;
CREATE TRIGGER record_appointment_insert AFTER INSERT ON appointments
BEGIN
  INSERT INTO appointment_events(tenant_id,appointment_code,kind,date,start_min)
  VALUES(NEW.tenant_id,NEW.code,'created',NEW.date,NEW.start_min);
END;
CREATE TRIGGER record_appointment_change AFTER UPDATE ON appointments
WHEN OLD.date!=NEW.date OR OLD.start_min!=NEW.start_min OR (OLD.status!=NEW.status AND NEW.status='cancelled')
BEGIN
  INSERT INTO appointment_events(tenant_id,appointment_code,kind,previous_date,previous_start,date,start_min)
  VALUES(NEW.tenant_id,NEW.code,CASE WHEN NEW.status='cancelled' THEN 'cancelled' ELSE 'rescheduled' END,OLD.date,OLD.start_min,NEW.date,NEW.start_min);
END;
