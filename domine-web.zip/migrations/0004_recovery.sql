CREATE TABLE waitlist (
  token TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  professional_id TEXT NOT NULL,
  service_id TEXT NOT NULL,
  date_from TEXT NOT NULL,
  date_to TEXT NOT NULL,
  nombre TEXT NOT NULL,
  apellido TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  consent INTEGER NOT NULL CHECK(consent IN (0,1)),
  reactivation INTEGER NOT NULL DEFAULT 0 CHECK(reactivation IN (0,1)),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revoked_at TEXT,
  FOREIGN KEY(tenant_id,professional_id,service_id) REFERENCES professional_services(tenant_id,professional_id,service_id)
);
CREATE UNIQUE INDEX waitlist_active ON waitlist(tenant_id,professional_id,service_id,phone,date_from,date_to) WHERE active=1;
CREATE TABLE recovery_jobs (
  event_id INTEGER PRIMARY KEY REFERENCES appointment_events(id),
  tenant_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE notifications (
  id TEXT PRIMARY KEY,
  event_id INTEGER NOT NULL REFERENCES appointment_events(id),
  tenant_id TEXT NOT NULL,
  waitlist_token TEXT NOT NULL REFERENCES waitlist(token),
  purpose TEXT NOT NULL CHECK(purpose IN ('availability','reactivation')),
  date TEXT NOT NULL,
  hora TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  provider_id TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(event_id)
);
CREATE TRIGGER queue_released_slot AFTER INSERT ON appointment_events
WHEN NEW.kind IN ('rescheduled','cancelled')
BEGIN
  INSERT INTO recovery_jobs(event_id,tenant_id) VALUES(NEW.id,NEW.tenant_id);
END;
