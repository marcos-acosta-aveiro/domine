import { test } from 'node:test';
import assert from 'node:assert/strict';
import { slotsFor, validateDate, validatePatient } from '../src/booking.js';

const now = new Date('2026-09-21T13:00:00Z');
test('duración, pasado, cierres y superposición', () => {
  const slots = slotsFor('2026-09-21', 60, [{ start_min: 450, end_min: 720 }], [{ start_min: 630, end_min: 660 }], now);
  assert.deepEqual(slots, ['11:00']);
});
test('las citas contiguas están permitidas', () => {
  assert.deepEqual(slotsFor('2026-09-22', 30, [{start_min: 480, end_min: 570}], [{start_min: 510, end_min: 540}], now), ['08:00','09:00']);
});
test('fechas inválidas, pasadas y fuera de horizonte', () => {
  for (const date of ['2026-02-30','2026-09-20','2028-01-01','no-fecha']) assert.throws(() => validateDate(date, now));
  assert.equal(validateDate('2026-09-22', now), '2026-09-22');
});
test('validación de paciente y límites', () => {
  const good = { nombre: ' Ana ', apellido:'Pérez', cod:'+595', tel:'981 123 456', email:'ANA@example.com' };
  assert.equal(validatePatient(good).nombre, 'Ana');
  assert.equal(validatePatient(good).email, 'ana@example.com');
  for (const input of [{...good, nombre:'A'}, {...good, email:'bad'}, {...good, tel:'123'}, {...good, nombre:'x'.repeat(81)}]) assert.throws(() => validatePatient(input));
});
