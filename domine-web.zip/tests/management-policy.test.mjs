import {test} from 'node:test';
import assert from 'node:assert/strict';
import {canChange} from '../src/manage.js';
test('6 horas exactas permitidas; 5h59 y turnos no confirmados bloqueados',()=>{
  const now=new Date('2026-09-22T12:00:00Z'); // 09:00 Asunción
  assert.equal(canChange({date:'2026-09-22',start_min:900,status:'confirmed'},{},now),true);
  assert.equal(canChange({date:'2026-09-22',start_min:899,status:'confirmed'},{},now),false);
  assert.equal(canChange({date:'2026-09-22',start_min:900,status:'confirmed'},{},new Date('2026-09-22T12:00:01Z')),false);
  assert.equal(canChange({date:'2026-09-22',start_min:1080,status:'cancelled'},{},now),false);
});
