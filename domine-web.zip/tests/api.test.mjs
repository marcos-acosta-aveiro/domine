import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import worker,{availability} from '../src/worker.js';
import {prepareRecovery,sendNotifications} from '../src/recovery.js';
import {clinicClock} from '../src/booking.js';

function setup(){
  const db=new DatabaseSync(':memory:');
  for(const file of fs.readdirSync('migrations').sort()) db.exec(fs.readFileSync('migrations/'+file,'utf8'));
  const env={TENANT_ID:'san-lucas',DB:{prepare(sql){return {bind(...args){ const statement=db.prepare(sql); return {async all(){return {results:statement.all(...args)};},async first(){return statement.get(...args)??null;},async run(){return statement.run(...args);}};}};}}};
  const call=(path,body,headers={})=>worker.fetch(new Request('http://localhost'+path,body?{method:'POST',headers:{'Content-Type':'application/json',...headers},body:JSON.stringify(body)}:undefined),env);
  let day=new Date(clinicClock().date+'T12:00:00Z'); day.setUTCDate(day.getUTCDate()+1); while([0,6].includes(day.getUTCDay())) day.setUTCDate(day.getUTCDate()+1);
  const body={doc:'d1',trat:'t3',fecha:day.toISOString().slice(0,10),hora:'08:00',pago:'consultorio',nombre:'Ana',apellido:'Prueba',cod:'+595',tel:'981123456',email:'ana@example.com',requestId:crypto.randomUUID()};
  return {db,call,body,env};
}

test('catálogo, persistencia, precio del servidor e idempotencia',async()=>{
  const {db,call,body}=setup();
  try {
    const catalog=await (await call('/api/catalog')).json();
    assert.equal(catalog.specialties.length,6); assert.equal(catalog.professionals.length,7); assert.equal(catalog.services.length,17);
    const response=await call('/api/appointments',{...body,price:1,motivo:'No almacenar'});
    assert.equal(response.status,201); const receipt=await response.json();
    assert.match(receipt.code,/^SL-[0-9A-F]{32}$/); assert.equal(receipt.total,450000);
    const repeat=await (await call('/api/appointments',body)).json(); assert.equal(repeat.code,receipt.code);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM appointments').get().n,1);
    assert.equal(db.prepare('SELECT patient_json FROM appointments').get().patient_json.includes('No almacenar'),false);
    const available=await (await call('/api/availability?'+new URLSearchParams({doc:'d1',trat:'t1',fecha:body.fecha}))).json();
    assert.equal(available.slots.includes('08:30'),false); assert.equal(available.slots.includes('09:00'),true);
  } finally {db.close();}
});

test('dos solicitudes simultáneas superpuestas: solo una reserva',async()=>{
  const {db,call,body}=setup();
  try {
    const responses=await Promise.all([call('/api/appointments',body),call('/api/appointments',{...body,hora:'08:30',requestId:crypto.randomUUID()})]);
    assert.deepEqual(responses.map(r=>r.status).sort(),[201,409]);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM appointments').get().n,1);
  } finally {db.close();}
});

test('rechaza servicio incompatible, pago online, origen externo y datos inválidos',async()=>{
  const {db,call,body}=setup();
  try {
    for(const data of [{...body,trat:'t5'},{...body,pago:'virtual'},{...body,email:'bad'},{...body,fecha:'2026-02-30'},{...body,hora:'25:00'}]) assert.equal((await call('/api/appointments',data)).status,400);
    assert.equal((await call('/api/appointments',body,{Origin:'https://other.example'})).status,403);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM appointments').get().n,0);
  } finally {db.close();}
});

test('bloqueos, sábados, domingos y aislamiento por clínica',async()=>{
  const {db,call,body}=setup();
  try {
    db.prepare('INSERT INTO blocks (tenant_id,professional_id,date) VALUES (?,?,?)').run('san-lucas','d1',body.fecha);
    const get=date=>call('/api/availability?'+new URLSearchParams({doc:'d1',trat:'t1',fecha:date})).then(r=>r.json());
    assert.deepEqual((await get(body.fecha)).slots,[]);
    let date=new Date(body.fecha+'T12:00:00Z'); while(date.getUTCDay()!==6) date.setUTCDate(date.getUTCDate()+1);
    const saturday=await get(date.toISOString().slice(0,10)); assert.equal(saturday.slots[0],'08:00'); assert.equal(saturday.slots.at(-1),'12:00');
    date.setUTCDate(date.getUTCDate()+1); assert.deepEqual((await get(date.toISOString().slice(0,10))).slots,[]);
    const response=await worker.fetch(new Request('http://localhost/api/catalog'),{TENANT_ID:'other',DB:{prepare:sql=>({bind:tenant=>({all:async()=>({results:db.prepare(sql).all(tenant)})})})}});
    assert.deepEqual((await response.json()).professionals,[]);
  } finally {db.close();}
});

test('gestión requiere código y correo; reagenda atómicamente y conserva historial',async()=>{
  const {db,call,body}=setup();
  try {
    const booked=await (await call('/api/appointments',body)).json();
    const auth={code:booked.code,email:body.email};
    assert.equal((await call('/api/manage/lookup',{...auth,email:'otro@example.com'})).status,404);
    const current=await (await call('/api/manage/lookup',auth)).json();
    assert.equal(current.appointment.hora,'08:00');
    const available=await (await call('/api/manage/availability',{...auth,fecha:body.fecha})).json();
    assert.ok(available.slots.includes('08:30'),'puede superponerse a su propio turno anterior');
    const change={...auth,fecha:body.fecha,hora:'08:30',version:current.appointment.version,operationId:crypto.randomUUID()};
    const response=await call('/api/manage/reschedule',change); assert.equal(response.status,200);
    const changed=await response.json(); assert.equal(changed.appointment.hora,'08:30'); assert.equal(changed.appointment.code,booked.code);
    assert.equal(changed.appointment.total,450000); assert.equal(changed.history.length,2);
    assert.equal((await call('/api/manage/reschedule',change)).status,200,'reintentar no cambia dos veces');
    assert.equal(db.prepare('SELECT COUNT(*) n FROM appointment_events').get().n,2);
    assert.equal((await call('/api/manage/reschedule',{...change,hora:'10:00',operationId:crypto.randomUUID()})).status,409);
  } finally {db.close();}
});

test('reagendamiento ocupado conserva el original; cancelar libera horario',async()=>{
  const {db,call,body}=setup();
  try {
    const booked=await (await call('/api/appointments',body)).json();
    await call('/api/appointments',{...body,hora:'10:00',requestId:crypto.randomUUID()});
    const auth={code:booked.code,email:body.email};
    const move=await call('/api/manage/reschedule',{...auth,fecha:body.fecha,hora:'10:00',version:1,operationId:crypto.randomUUID()});
    assert.equal(move.status,409);
    assert.equal(db.prepare('SELECT start_min FROM appointments WHERE code=?').get(booked.code).start_min,480);
    const cancel={...auth,version:1,operationId:crypto.randomUUID()};
    const result=await call('/api/manage/cancel',cancel); assert.equal(result.status,200);
    assert.equal((await result.json()).appointment.status,'cancelled');
    assert.equal((await call('/api/manage/cancel',cancel)).status,200);
    const slots=await (await call('/api/availability?'+new URLSearchParams({doc:'d1',trat:'t3',fecha:body.fecha}))).json();
    assert.ok(slots.slots.includes('08:00'));
    assert.equal((await call('/api/manage/reschedule',{...auth,fecha:body.fecha,hora:'14:00',version:2,operationId:crypto.randomUUID()})).status,409);
  } finally {db.close();}
});

test('gestión no permite cambiar turnos pasados ni fechas imposibles',async()=>{
  const {db,call,body}=setup();
  try {
    const booked=await (await call('/api/appointments',body)).json();
    const auth={code:booked.code,email:body.email,version:1,operationId:crypto.randomUUID()};
    assert.equal((await call('/api/manage/reschedule',{...auth,fecha:'2026-02-30',hora:'08:00'})).status,400);
    db.prepare("UPDATE appointments SET date='2020-01-01' WHERE code=?").run(booked.code);
    assert.equal((await call('/api/manage/cancel',auth)).status,409);
  } finally {db.close();}
});

test('lista exige consentimiento y revoca permisos',async()=>{
  const {db,call,body}=setup();
  try{
    const entry={doc:'d1',trat:'t3',from:body.fecha,to:body.fecha,nombre:'Luis',apellido:'Prueba',email:'luis@example.com',phone:'+595981222222',consent:false};
    assert.equal((await call('/api/waitlist',entry)).status,400);
    const response=await call('/api/waitlist',{...entry,consent:true,reactivation:true});assert.equal(response.status,200);
    const {token}=await response.json();assert.match(token,/^[a-f0-9]{32}$/);
    assert.equal((await call('/api/waitlist',{...entry,consent:true})).status,409);
    await call('/api/waitlist/leave',{token});
    const row=db.prepare('SELECT * FROM waitlist WHERE token=?').get(token);assert.equal(row.active,0);assert.equal(row.consent,0);assert.equal(row.reactivation,0);
  }finally{db.close();}
});

test('cancelación prepara una oferta compatible; modo desactivado no envía; envío revocado se cancela',async()=>{
  const {db,call,body,env}=setup();
  try{
    const entry={doc:'d1',trat:'t3',from:body.fecha,to:body.fecha,nombre:'Luis',apellido:'Prueba',email:'luis@example.com',phone:'+595981222222',consent:true};
    const {token}=await (await call('/api/waitlist',entry)).json();
    const booked=await (await call('/api/appointments',body)).json();
    await call('/api/manage/cancel',{code:booked.code,email:body.email,version:1,operationId:crypto.randomUUID()});
    assert.equal((await prepareRecovery(env,availability)).queued,1);
    await prepareRecovery(env,availability);assert.equal(db.prepare('SELECT COUNT(*) n FROM notifications').get().n,1);
    let calls=0;const sender=async()=>{calls++;return Response.json({messages:[{id:'fake-id'}]});};
    assert.equal((await sendNotifications(env,availability,sender)).disabled,true);assert.equal(calls,0);
    await call('/api/waitlist/leave',{token});
    await sendNotifications({...env,WHATSAPP_ENABLED:'true',WHATSAPP_TOKEN:'test',WHATSAPP_PHONE_ID:'123',WHATSAPP_API_VERSION:'v23.0',PUBLIC_URL:'https://example.com'},availability,sender);
    assert.equal(calls,0);assert.equal(db.prepare('SELECT status FROM notifications').get().status,'cancelled');
  }finally{db.close();}
});

test('plantilla WhatsApp usa consentimiento y no duplica el envío',async()=>{
  const {db,call,body,env}=setup();
  try{
    await call('/api/waitlist',{doc:'d1',trat:'t3',from:body.fecha,to:body.fecha,nombre:'Luis',apellido:'Prueba',email:'luis@example.com',phone:'+595981222222',consent:true});
    const booked=await (await call('/api/appointments',body)).json();
    await call('/api/manage/cancel',{code:booked.code,email:body.email,version:1,operationId:crypto.randomUUID()});await prepareRecovery(env,availability);
    let calls=0;const sender=async(url,options)=>{calls++;const payload=JSON.parse(options.body);assert.equal(payload.type,'template');assert.equal(payload.to,'595981222222');assert.equal(payload.template.name,'horario_disponible');assert.ok(payload.template.components[0].parameters[4].text.includes('#leave='));return Response.json({messages:[{id:'fake-id'}]});};
    const enabled={...env,WHATSAPP_ENABLED:'true',WHATSAPP_TOKEN:'test',WHATSAPP_PHONE_ID:'123',WHATSAPP_API_VERSION:'v23.0',PUBLIC_URL:'https://example.com',WHATSAPP_AVAILABILITY_TEMPLATE:'horario_disponible'};
    await sendNotifications(enabled,availability,sender);await sendNotifications(enabled,availability,sender);assert.equal(calls,1);
    assert.equal(db.prepare('SELECT status FROM notifications').get().status,'sent');
  }finally{db.close();}
});

test('dos pacientes cambian al mismo horario: uno conserva su turno original',async()=>{
  const {db,call,body}=setup();
  try{
    const a=await (await call('/api/appointments',body)).json();
    const b=await (await call('/api/appointments',{...body,hora:'10:00',requestId:crypto.randomUUID()})).json();
    const replies=await Promise.all([a,b].map(booked=>call('/api/manage/reschedule',{code:booked.code,email:body.email,fecha:body.fecha,hora:'14:00',version:1,operationId:crypto.randomUUID()})));
    assert.deepEqual(replies.map(r=>r.status).sort(),[200,409]);
    const loser=replies[0].status===409?a:b;
    assert.equal(db.prepare('SELECT start_min FROM appointments WHERE code=?').get(loser.code).start_min,loser===a?480:600);
  }finally{db.close();}
});

test('reactivación exige visita antigua, permiso específico y ausencia de próxima reserva',async()=>{
  for(const scenario of ['eligible','no-consent','recent','future']){
    const {db,call,body,env}=setup();
    try{
      const former=await (await call('/api/appointments',{...body,email:'luis@example.com'})).json();
      db.prepare("UPDATE appointments SET status='attended',date=? WHERE code=?").run(scenario==='recent'?clinicClock().date:'2020-01-01',former.code);
      // Outside the requested date range: only explicit reactivation can match.
      await call('/api/waitlist',{doc:'d1',trat:'t3',from:clinicClock().date,to:clinicClock().date,nombre:'Luis',apellido:'Prueba',email:'luis@example.com',phone:'+595981222222',consent:true,reactivation:scenario!=='no-consent'});
      if(scenario==='future') await call('/api/appointments',{...body,email:'luis@example.com',hora:'15:00',requestId:crypto.randomUUID()});
      const booked=await (await call('/api/appointments',{...body,requestId:crypto.randomUUID()})).json();
      await call('/api/manage/cancel',{code:booked.code,email:body.email,version:1,operationId:crypto.randomUUID()});
      await prepareRecovery(env,availability);
      const offers=db.prepare('SELECT purpose FROM notifications').all();
      assert.equal(offers.length,scenario==='eligible'?1:0,scenario);
      if(offers.length) assert.equal(offers[0].purpose,'reactivation');
    }finally{db.close();}
  }
});
