# Verificación local — 22 de septiembre de 2026

## Aplicación y datos

- `npm test`: 17 pruebas aprobadas. SQLite real: reservas, precios, duración, bloqueos, fechas, aislamiento por clínica, concurrencia, idempotencia, historial, cancelación y permisos.
- Límite: exactamente 6 horas permitido; 5h59 y 5h59m59s bloqueados. Regresión observada antes de corregir el redondeo por minutos.
- Dos pacientes intentando reagendar al mismo horario: uno cambia y el otro conserva su reserva original.
- Reactivación: permiso específico, visita antigua marcada atendida, ninguna consulta reciente ni reserva futura.
- `npm run build`: correcto. `node --check` en JS de src/config/scripts/tests: correcto.
- Cuatro migraciones aplicadas a D1 local. `node tests/local-smoke.mjs`: reserva persistida, precio, concurrencia, consulta, reagendamiento, historial, cancelación y alta/baja de espera correctos por HTTP contra Wrangler.
- Cron local invocado mediante `/cdn-cgi/local/scheduled`: respuesta `ok`. WhatsApp desactivado.
- Paquete `wrangler deploy --dry-run` validado. No hubo publicación remota.

## Navegador e interacción

- Reserva completa desde móvil: profesional, servicio, día, hora, datos ficticios, pago en consultorio y confirmación.
- «Mi turno»: consulta, comparación de horarios, cambio persistido con el mismo código e historial. Confirmación explícita de cancelación verificada.
- Lista de espera: alta con consentimiento y retiro con código privado verificados.
- Archivo `consulta.ics` descargado y leído: UID de reserva, secuencia de versión, inicio/fin y zona America/Asuncion correctos. El evento del harness de descarga agotó tiempo; la descarga real sí se produjo.
- Foco: CTA lleva al encabezado destino; conservar turno vuelve a «Elegir otro horario». Un conflicto real 409 enfoca el error; Tab permite volver a confirmar. Evidencia detallada en `.impeccable/review/accessibility-checks.md`.
- Teclado: flechas/Home/End entre pestañas; animaciones desactivadas en keyboard-mode. Reduced motion se respeta en CSS y desplazamientos JS.
- Capturas de portada en 390, 768, 1280 y 1440; gestión y comparación en 390/1440. Sin desborde horizontal en esos recorridos. Fotos cargadas antes de capturar.
- Consola: sin errores JavaScript en los flujos revisados.

## Alcance y límites

Es una demo local funcional con API, no un despliegue productivo. No se enviaron WhatsApp reales; la integración de plantillas se probó con un emisor simulado. Meta, dominio y D1 remoto requieren configuración del cliente. No incluye cobro online, panel administrativo ni sincronización de calendario. Las invitaciones de retorno requieren datos de asistencia reales; hoy no hay panel para cargarlos.

No se hizo certificación WCAG, prueba de carga, lector de pantalla ni prueba en dispositivos físicos. Fotos y tipografías dependen de proveedores externos. Antes de atender pacientes reales se deben completar identidad, privacidad, protección antiabuso y procedimiento de recuperación de códigos, como detalla README.md.

Revisión Impeccable: primera pasada pidió tres correcciones concretas de foco y tamaño de controles. El revisor independiente calificó las tres como resueltas: `disposition: ship` sobre esos ajustes. Evidencia y alcance en `.impeccable/review/verdict.md`. Los turnos ficticios creados para la revisión final quedaron cancelados, conservando historial.
