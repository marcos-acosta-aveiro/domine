# Dómine · Plantilla para clínicas

Web adaptable con catálogo, reservas, consulta privada del turno, reagendamiento, cancelación, comprobantes, calendario y lista de espera. Diseño claro con Sora, Inter, fondo mineral, tinta petróleo y verde. Los datos y fotografías actuales son demostrativos.

## Ejecutar y verificar

Node.js 24. Desde esta carpeta:

```sh
npm ci
npm run db:local
npm run dev
```

Abrí http://127.0.0.1:8787. No abras el HTML con doble clic: necesita la API. Después de editar frontend, ejecutá `npm run build` y recargá. D1 local persiste en `.wrangler/state`, sin modificar la base remota.

```sh
npm test
npm run build
node tests/local-smoke.mjs
npx wrangler deploy --dry-run
```

El smoke test requiere Wrangler encendido. Crea y cancela una reserva ficticia y prueba alta/baja de espera. Las pruebas automáticas usan SQLite real y WhatsApp simulado; no contactan pacientes.

## Adaptar al primer cliente

1. Editá `config/clinic.js`: nombre, textos, colores, imagen, contacto y horario visible. Mantené `demo: true` hasta sustituir todo el contenido ficticio.
2. Cargá profesionales, especialidades y servicios reales mediante una nueva migración D1. `migrations/0002_demo.sql` muestra el formato. Los campos JSON de presentación deben coincidir con precio, duración e identificadores relacionales. Sustituí fotos, biografías y registros profesionales de ejemplo.
3. Configurá `schedules` y `blocks`: horarios, vacaciones y cierres. El texto `hours` solo informa; no cambia la agenda SQL.
4. Completá contacto y aviso de privacidad. Verificá contraste si cambiás los colores. Las imágenes y fuentes actuales se cargan desde Unsplash y Google Fonts.
5. Usá un Worker y una base separados por cliente. `TENANT_ID` selecciona la clínica en servidor. El valor heredado `san-lucas` es una clave interna, no la marca. Cambiarlo requiere migrar los registros relacionados.

La localización actual es Paraguay: guaraníes y `America/Asuncion`. Para otro país hay que actualizar moneda, textos y lógica de fechas conjuntamente; `timezone` no cambia toda la aplicación por sí solo. El límite de 6 horas está aplicado en servidor y textos.

## Reserva y gestión

- Agenda de 90 días, inicios cada 15 minutos, respetando toda la duración del servicio. El servidor determina precio y disponibilidad; triggers SQL impiden superposiciones concurrentes.
- «Mi turno» requiere código privado aleatorio y correo. No viajan en URL. Guardá el código: no hay recuperación automática por correo.
- Reagendar y cancelar **hasta 6 horas antes**, inclusive. Con menos tiempo, la gestión online se bloquea.
- El cambio conserva profesional, servicio, importe y código. La reserva original permanece hasta confirmar atómicamente la nueva. Si otro paciente ocupa ese horario, el original se conserva.
- El historial se registra en la misma operación SQL. La versión evita sobrescribir cambios de otra pestaña. Repetir la última operación con el mismo identificador no la duplica.
- Comprobante descargable y calendario `.ics`. Después de cambiar el turno, descargá la versión actualizada: no hay sincronización con calendarios externos.
- Pago en consultorio, sin cobro online. La nota opcional solo queda en el comprobante del navegador.

## Lista de espera y WhatsApp

Guarda profesional, servicio, rango de fechas y consentimiento. Las invitaciones futuras requieren un permiso separado. El código privado de la lista permite retirar todos esos permisos.

Cambiar o cancelar crea un trabajo persistente. Cada cinco minutos, un Cron Trigger busca un candidato compatible de la lista. Si no hay candidato, puede seleccionar una invitación de retorno con consentimiento específico, una consulta `attended` de hace al menos 180 días y ninguna consulta reciente ni próxima reserva. No se infiere necesidad médica. **No hay panel para marcar asistencia**: la clínica debe integrar ese dato para usar reactivación.

Se prepara una oferta por evento, sin bloquear el horario. Se verifican permiso y disponibilidad antes de enviar. El enlace abre la agenda para reservar; no confirma automáticamente. No hay cascada a otros candidatos si el primero ignora la oferta. Límites de frecuencia por solicitud: 7 días para disponibilidad, 30 para retorno.

**Envíos desactivados por defecto.** Para activar WhatsApp Cloud API se necesitan cuenta/número de Meta, token y dos plantillas aprobadas. Variables de `wrangler.jsonc`:

| Variable | Valor |
| --- | --- |
| `WHATSAPP_ENABLED` | `true` cuando esté configurado |
| `WHATSAPP_PHONE_ID` | ID del número de Meta |
| `WHATSAPP_API_VERSION` | Versión admitida por Meta, formato `vN.N` |
| `WHATSAPP_LANGUAGE` | Idioma de las plantillas, por defecto `es` |
| `WHATSAPP_AVAILABILITY_TEMPLATE` | Nombre de plantilla de disponibilidad |
| `WHATSAPP_REACTIVATION_TEMPLATE` | Nombre de plantilla de retorno |
| `PUBLIC_URL` | URL pública HTTPS de la clínica |

El token se guarda como secreto:

```sh
npx wrangler secret put WHATSAPP_TOKEN
```

Ambas plantillas reciben cinco parámetros de cuerpo: nombre, fecha ISO, hora, enlace de reserva, enlace de baja. La de retorno debe expresar una invitación opcional sin diagnóstico ni promesa de necesidad de revisión. Revisá categorías y aprobación en Meta. Referencia: [WhatsApp Cloud API, documentación de Meta](https://www.postman.com/meta/whatsapp-business-platform/documentation/wlk6lh4/whatsapp-cloud-api).

En local, `.dev.vars` admite secretos y está ignorado por Git. Para procesar trabajos manualmente, conservando los envíos desactivados:

```sh
curl http://127.0.0.1:8787/cdn-cgi/local/scheduled
```

`notifications.status='sent'` significa aceptado por Meta, no entregado/leído. No hay webhook de recepción ni procesamiento de respuestas: la baja funciona con el enlace web. Estados `failed`, `unknown` o `sending` interrumpido necesitan revisión; una respuesta ambigua no se reintenta automáticamente. Confirmá el resultado en Meta antes de reintentar manualmente.

## Publicar en Cloudflare

Workers Static Assets + D1 + Cron Triggers. El ID `00000000-0000-0000-0000-000000000000` es de desarrollo; no identifica una base remota.

```sh
npx wrangler login
npx wrangler d1 create domine-clinica
```

Copiá el ID devuelto a `wrangler.jsonc`, conservando el binding `DB`:

```sh
npm test
npm run db:remote
npm run deploy
```

Wrangler devuelve la URL pública. Las migraciones se aplican una vez: para instalaciones existentes, agregá nuevas migraciones. No reimportes el prototipo sobre archivos editados. Logs: `npx wrangler tail`.

Antes de atender pacientes reales faltan configuración del cliente, protección antiabuso de formularios, un procedimiento de recuperación de códigos y la integración operativa de asistencia. No hay panel administrativo ni verificación de titularidad de correo/teléfono. No se ha publicado ni enviado mensajes reales.

## Estructura

| Archivo | Responsabilidad |
| --- | --- |
| `config/clinic.js` | Identidad pública |
| `index.html`, `src/premium.css` | Estructura y diseño |
| `src/app.js`, `src/connection.js` | Reserva y catálogo |
| `src/portal.js` | Gestión, espera, calendario, ayuda |
| `src/worker.js`, `src/booking.js`, `src/http.js` | API y validación |
| `src/manage.js` | Operaciones y política de cambios |
| `src/waitlist.js`, `src/recovery.js` | Permisos, candidatos y ofertas |
| `migrations/` | Esquema, demo e historial |
| `DESIGN.md`, `.impeccable/design.json` | Sistema visual y tokens |
| `VERIFICACION.md` | Evidencias y alcance de pruebas |

Los logs propios omiten cuerpos, códigos y datos personales. JSON usa `Cache-Control: no-store`. Solo `dist/` se sirve como archivos estáticos.

Referencias: [Static Assets](https://developers.cloudflare.com/workers/static-assets/), [Wrangler](https://developers.cloudflare.com/workers/wrangler/configuration/), [D1 local](https://developers.cloudflare.com/d1/best-practices/local-development/), [Cron Triggers](https://developers.cloudflare.com/workers/configuration/cron-triggers/).
